import sys
from pathlib import Path
import streamlit as st
import httpx
import os
from PyPDF2 import PdfReader
import docx
import textstat
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.tokenize import sent_tokenize
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

current_dir = Path(__file__).parent
project_root = current_dir.parent
sys.path.append(str(project_root))
from backend.schemas import UserCreate, UserLogin

st.set_page_config(
    page_title="TextMorph Advanced",
    layout="centered",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
    :root {
        --primary: #2563EB;
        --primary-dark: #1D4ED8;
        --background: #0F172A;
        --secondary-background: #1E293B;
        --text: #F1F5F9;
        --text-secondary: #94A3B8;
        --accent: #3B82F6;
    }
    .stApp {
        background: linear-gradient(135deg, var(--background) 0%, #1E40AF 100%);
        color: var(--text);
    }
    .css-1d391kg, .css-1d391kg p, .css-1d391kg label {
        background: var(--secondary-background) !important;
        color: var(--text) !important;
        border-right: 2px solid var(--primary);
    }
    h1, h2, h3, h4, h5, h6 {
        color: var(--text) !important;
        font-weight: 700 !important;
    }
    p, label, .stTextInput, .stSelectbox, .stTextArea {
        color: var(--text) !important;
    }
    .stButton>button {
        background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%) !important;
        color: white !important;
        border: none;
        border-radius: 12px;
        padding: 0.75rem 1.5rem;
        font-weight: 600;
        transition: all 0.3s ease;
    }
    .stButton>button:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(37, 99, 235, 0.3);
    }
    .stTextInput>div>div>input, 
    .stSelectbox>div>div>select,
    .stTextArea>div>div>textarea {
        background: var(--secondary-background) !important;
        color: var(--text) !important;
        border: 2px solid #334155;
        border-radius: 10px;
        padding: 12px;
    }
    .stFileUploader>div>div {
        background: var(--secondary-background) !important;
        border: 2px dashed var(--primary) !important;
        border-radius: 15px !important;
    }
    .stForm {
        background: var(--secondary-background) !important;
        border-radius: 20px !important;
        padding: 2rem !important;
        border: 1px solid #334155;
    }
    .stMetric {
        background: linear-gradient(135deg, var(--secondary-background) 0%, #2D3748 100%);
        border-radius: 15px;
        padding: 1rem;
        border: 1px solid #334155;
    }
    .stSuccess {
        background: linear-gradient(135deg, #065F46 0%, #047857 100%) !important;
        color: white !important;
        border-radius: 15px;
        border: none;
    }
    .stError {
        background: linear-gradient(135deg, #7F1D1D 0%, #B91C1C 100%) !important;
        color: white !important;
        border-radius: 15px;
        border: none;
    }
    .stInfo {
        background: linear-gradient(135deg, var(--secondary-background) 0%, #2D3748 100%) !important;
        color: var(--text) !important;
        border-radius: 15px;
        border: 1px solid var(--primary);
    }
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
    }
    .stTabs [data-baseweb="tab"] {
        background: var(--secondary-background);
        border-radius: 10px 10px 0 0;
        padding: 12px 24px;
        font-weight: 600;
        border: 1px solid #334155;
    }
    .stTabs [aria-selected="true"] {
        background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%) !important;
        color: white !important;
    }
</style>
""", unsafe_allow_html=True)

BACKEND_URL = "http://127.0.0.1:8000"

# Initialize session state
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
if 'token' not in st.session_state:
    st.session_state.token = None
if 'profile_image' not in st.session_state:
    st.session_state.profile_image = None
if 'user_id' not in st.session_state:
    st.session_state.user_id = None
if 'menu' not in st.session_state:
    st.session_state.menu = "Login"

def extract_text_from_file(uploaded_file):
    """Extract text from uploaded files"""
    try:
        if uploaded_file.type == "application/pdf":
            pdf_reader = PdfReader(uploaded_file)
            text = ""
            for page in pdf_reader.pages:
                text += page.extract_text() + "\n"
            return text
        elif uploaded_file.type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
            doc = docx.Document(uploaded_file)
            return "\n".join([paragraph.text for paragraph in doc.paragraphs])
        elif uploaded_file.type == "text/plain":
            return uploaded_file.getvalue().decode("utf-8")
        else:
            return None
    except Exception as e:
        st.error(f"Error extracting text: {e}")
        return None

def generate_summary(text, num_sentences=3):
    """Simple extractive summarization"""
    try:
        sentences = sent_tokenize(text)
        if len(sentences) <= num_sentences:
            return text
        vectorizer = TfidfVectorizer(stop_words='english')
        tfidf_matrix = vectorizer.fit_transform(sentences)
        sentence_scores = np.array(tfidf_matrix.sum(axis=1)).flatten()
        top_sentence_indices = sentence_scores.argsort()[-num_sentences:][::-1]
        top_sentences = [sentences[i] for i in sorted(top_sentence_indices)]
        return " ".join(top_sentences)
    except Exception as e:
        sentences = text.split('.')
        return '. '.join(sentences[:num_sentences]) + '.'

def calculate_readability_scores(text):
    """Calculate readability scores"""
    if not text.strip():
        return None
    try:
        return {
            'flesch_score': textstat.flesch_reading_ease(text),
            'smog_index': textstat.smog_index(text),
            'word_count': len(text.split()),
            'sentence_count': textstat.sentence_count(text),
            'text_complexity': get_complexity_level(textstat.flesch_reading_ease(text))
        }
    except Exception as e:
        st.error(f"Error calculating scores: {e}")
        return None

def get_complexity_level(flesch_score):
    """Convert Flesch score to complexity level"""
    if flesch_score >= 90: return "Very Easy"
    elif flesch_score >= 80: return "Easy"
    elif flesch_score >= 70: return "Fairly Easy"
    elif flesch_score >= 60: return "Standard"
    elif flesch_score >= 50: return "Fairly Difficult"
    elif flesch_score >= 30: return "Difficult"
    else: return "Very Difficult"

def create_visualization(scores, summary_words):
    """Create readability visualization"""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
    
    # Pie chart for complexity
    complexity_levels = ['Very Easy', 'Easy', 'Fairly Easy', 'Standard', 'Fairly Difficult', 'Difficult', 'Very Difficult']
    complexity_values = [0] * 7
    complexity_index = complexity_levels.index(scores['text_complexity'])
    complexity_values[complexity_index] = 1
    
    colors = ['#22C55E', '#4ADE80', '#86EFAC', '#F59E0B', '#F97316', '#EF4444', '#DC2626']
    ax1.pie(complexity_values, labels=complexity_levels, colors=colors, autopct='%1.0f%%')
    ax1.set_title('Text Complexity Level', fontweight='bold', fontsize=14)
    
    # Bar chart for scores
    metrics = ['Flesch Score', 'SMOG Index']
    values = [scores['flesch_score'], scores['smog_index']]
    colors = ['#2563EB', '#8B5CF6']
    bars = ax2.bar(metrics, values, color=colors, alpha=0.8)
    ax2.set_ylabel('Score', fontweight='bold')
    ax2.set_title('Readability Metrics', fontweight='bold', fontsize=14)
    ax2.set_ylim(0, 100)
    
    for bar, value in zip(bars, values):
        ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 2,
                f'{value:.1f}', ha='center', va='bottom', fontweight='bold')
    
    plt.tight_layout()
    return fig

# ========== MAIN INTERFACE ==========
st.title("TextMorph Advanced Summarization & Paraphrasing")
st.markdown("---")

# Sidebar navigation - UPDATED
st.sidebar.title("Navigation")
menu_options = ["Login", "Register", "Profile", "Text Analysis", "AI Studio"]
menu = st.sidebar.selectbox("Menu", menu_options, key="menu_select")

# Show login page first if not logged in
if not st.session_state.logged_in and menu != "Register":
    menu = "Login"

if menu == "Register":
    st.header("Create a New Account")
    with st.form("register_form"):
        username = st.text_input("Username")
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("Create Account")
        if submitted:
            try:
                new_user = UserCreate(username=username, email=email, password=password)
                response = httpx.post(f"{BACKEND_URL}/register", json=new_user.model_dump())
                if response.status_code == 200:
                    st.success("Registration successful! Please log in.")
                    st.session_state.user_id = username  # Set user ID
                else:
                    st.error(response.json().get('detail', 'Registration failed'))
            except Exception as e:
                st.error(f"An error occurred: {e}")

elif menu == "Login":
    st.header("Login to Your Account")
    with st.form("login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("Login")
        if submitted:
            try:
                form_data = {'username': username, 'password': password}
                response = httpx.post(f"{BACKEND_URL}/token", data=form_data)
                if response.status_code == 200:
                    token_data = response.json()
                    st.session_state.logged_in = True
                    st.session_state.token = token_data['access_token']
                    st.session_state.user_id = username  # Set user ID for AI sequencing
                    st.success("Login successful!")
                    st.rerun()
                else:
                    st.error("Invalid username or password")
            except Exception as e:
                st.error(f"Login failed: {e}")
    
    # Comparison table
    st.markdown("---")
    st.subheader("🤖 AI Capabilities Comparison")
    
    comparison_data = {
        'Feature': ['Summarization', 'Paraphrasing', 'ROUGE Evaluation', 'Complexity Levels'],
        'Pegasus': ['✅ Excellent', '❌ No', '✅ Yes', '❌ No'],
        'BART': ['✅ Very Good', '❌ No', '✅ Yes', '❌ No'], 
        'FLAN-T5': ['✅ Good', '✅ Excellent', '✅ Yes', '✅ Yes']
    }
    
    st.table(comparison_data)
    st.caption("Login to access advanced AI features!")

elif menu == "Profile":
    if not st.session_state.logged_in:
        st.warning("Please log in to view your profile.")
    else:
        st.header("Your Profile")
        
        # Profile picture upload
        st.subheader("🖼️ Profile Picture")
        uploaded_image = st.file_uploader("Upload profile image", type=['png', 'jpg', 'jpeg'])
        if uploaded_image:
            st.session_state.profile_image = uploaded_image
            st.image(uploaded_image, width=150)
        
        try:
            headers = {"Authorization": f"Bearer {st.session_state.token}"}
            response = httpx.get(f"{BACKEND_URL}/profile", headers=headers)
            
            if response.status_code == 200:
                profile_data = response.json()
                user = profile_data['user']
                prefs = profile_data['preferences']

                with st.form("profile_form"):
                    st.subheader("Account Information")
                    st.text_input("Username", value=user['username'], disabled=True)
                    new_email = st.text_input("Email", value=user['email'])

                    st.subheader("Reading Preferences")
                    language = st.selectbox("Preferred Language", options=['en', 'es', 'fr', 'de'])
                    reading_style = st.selectbox("Reading Style", options=['neutral', 'formal', 'casual', 'concise'])
                    content_type = st.selectbox("Content Type", options=['general', 'news', 'academic', 'technical'])

                    submitted = st.form_submit_button("Update Profile")
                    if submitted:
                        update_data = {
                            "email": new_email,
                            "preferences": {"language": language, "reading_style": reading_style, "content_type": content_type}
                        }
                        update_response = httpx.put(f"{BACKEND_URL}/profile", json=update_data, headers=headers)
                        if update_response.status_code == 200:
                            st.success("Profile updated successfully!")
                        else:
                            st.error("Failed to update profile.")
            else:
                st.error("Could not fetch your profile.")
        except Exception as e:
            st.error(f"An error occurred: {e}")

elif menu == "Text Analysis":
    if not st.session_state.logged_in:
        st.warning("Please log in to analyze text.")
    else:
        st.header("📊 Text Analysis & Summarization")
        
        # File upload section
        st.subheader("📁 Upload File")
        uploaded_file = st.file_uploader("Choose a file", type=['txt', 'pdf', 'docx'], key="file_uploader")
        
        extracted_text = ""
        if uploaded_file is not None:
            extracted_text = extract_text_from_file(uploaded_file)
            if extracted_text:
                st.success("✅ File uploaded successfully!")
                with st.expander("View Extracted Text"):
                    st.text_area("Text", extracted_text, height=150, disabled=True, key="extracted_text")
        
        # Direct text input
        st.subheader("📝 Or Enter Text Directly")
        direct_text = st.text_area("Paste your text here:", height=100, key="direct_text")
        
        final_text = extracted_text if extracted_text else direct_text
        
        if st.button("Analyze & Summarize", type="primary", key="analyze_btn") and final_text.strip():
            with st.spinner("Analyzing text..."):
                scores = calculate_readability_scores(final_text)
                
                if scores:
                    summary = generate_summary(final_text)
                    
                    # Display scores
                    st.subheader("📈 Readability Analysis")
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Flesch Score", f"{scores['flesch_score']:.1f}", scores['text_complexity'])
                    with col2:
                        st.metric("SMOG Index", f"{scores['smog_index']:.1f}")
                    with col3:
                        st.metric("Word Count", scores['word_count'])
                    
                    # Display summary
                    st.subheader("📝 Generated Summary")
                    st.info(summary)
                    
                    # Show statistics
                    summary_words = len(summary.split())
                    reduction = ((scores['word_count'] - summary_words) / scores['word_count']) * 100
                    st.write(f"**Summary Statistics:** {summary_words} words ({reduction:.1f}% reduction)")
                    
                    # Visualization
                    st.subheader("📊 Visualization")
                    fig = create_visualization(scores, summary_words)
                    st.pyplot(fig)

# ENHANCED AI STUDIO SECTION WITH TABS
elif menu == "AI Studio":
    if not st.session_state.logged_in:
        st.warning("Please log in to access AI Studio.")
    else:
        st.header("AI Studio: Advanced Summarization & Paraphrasing")
        
        # Initialize AI processor
        try:
            from backend.ai_models import ai_processor
        except Exception as e:
            st.error(f"AI models not available: {e}")
            st.stop()
        
        # Show available models
        with st.expander("📋 Available Models Info"):
            st.subheader("Summarization Models")
            st.markdown("""
            - **BART**: Facebook's BART-large-cnn - Excellent for summarization
            - **Pegasus**: Google's Pegasus-xsum - Very good for abstractive summarization  
            - **FLAN-T5**: Google's FLAN-T5-base - Good for instruction-based summarization
            """)
            
            st.subheader("Paraphrasing Models")
            st.markdown("""
            - **Humarin-T5**: ChatGPT-style paraphrasing on T5 base
            - **T5-Large**: General purpose paraphrasing with larger capacity
            """)
        
        # Create tabs for better organization
        tab1, tab2 = st.tabs(["🤖 AI Summarization", "🔄 AI Paraphrasing"])
        
        with tab1:
            st.subheader("AI Summarization")
            
            # Show model sequence information
            try:
                remaining_models = ai_processor.get_remaining_summarization_models(st.session_state.user_id)
                used_models = []
                if st.session_state.user_id in ai_processor.user_sessions:
                    used_models = ai_processor.user_sessions[st.session_state.user_id].get('used_summarization_models', [])
                
                if used_models:
                    current_model = used_models[-1] if used_models else "BART"
                    st.info(f"🔁 Model Rotation: Last used: **{current_model.upper()}** | Next: **{remaining_models[0].upper() if remaining_models else 'BART'}**")
            except:
                st.info("🔁 Model Rotation: BART → Pegasus → FLAN-T5")
            
            # File upload for summarization
            st.subheader("📁 Upload File for Summarization")
            summ_uploaded_file = st.file_uploader("Choose a file", type=['txt', 'pdf', 'docx'], key="summ_file_uploader")
            
            summ_extracted_text = ""
            if summ_uploaded_file is not None:
                summ_extracted_text = extract_text_from_file(summ_uploaded_file)
                if summ_extracted_text:
                    st.success("✅ File uploaded successfully!")
                    with st.expander("View Extracted Text"):
                        st.text_area("Text", summ_extracted_text, height=150, disabled=True, key="summ_extracted_text")
            
            # Direct text input for summarization
            st.subheader("📝 Or Enter Text Directly")
            summ_direct_text = st.text_area("Paste your text for summarization:", height=200, key="summ_text")
            
            summ_final_text = summ_extracted_text if summ_extracted_text else summ_direct_text
            
            length_choice = st.radio("Summary Length:", ["short", "medium", "long"], horizontal=True, key="length_choice")
            
            if st.button("Generate AI Summary", key="ai_summarize_btn", type="primary"):
                if summ_final_text.strip():
                    with st.spinner("Generating AI summary..."):
                        try:
                            result = ai_processor.summarize(summ_final_text, st.session_state.user_id, length_choice, st.session_state.user_id)
                            
                            if 'error' in result.get('summary', '').lower():
                                st.error(result['summary'])
                            else:
                                st.success(f"✅ Summary generated using {result['model_used'].upper()}!")
                                st.text_area("AI Summary", result['summary'], height=150, key="ai_summary_output")

                                # Side-by-side comparison for summarization
                                st.subheader("🆚 Comparison")
                                comp_col1, comp_col2 = st.columns(2)
                                with comp_col1:
                                    st.text_area("Original Text", summ_final_text, height=150, disabled=True, key="original_text_display")
                                with comp_col2:
                                    st.text_area("AI Summary", result['summary'], height=150, disabled=True, key="summary_text_display")

                                # Show summary statistics
                                original_words = len(summ_final_text.split())
                                summary_words = len(result['summary'].split())
                                reduction = ((original_words - summary_words) / original_words) * 100 if original_words > 0 else 0

                                st.subheader("📊 Summary Statistics")
                                stat_col1, stat_col2, stat_col3 = st.columns(3)
                                with stat_col1:
                                    st.metric("Original Words", original_words)
                                with stat_col2:
                                    st.metric("Summary Words", summary_words)
                                with stat_col3:
                                    st.metric("Reduction", f"{reduction:.1f}%")

                                # Show ROUGE scores with visualization
                                st.subheader("📊 ROUGE Evaluation")
                                
                                # Check if ROUGE scores are available and not zero
                                if 'rouge_scores' in result and result['rouge_scores']:
                                    rouge_col1, rouge_col2, rouge_col3 = st.columns(3)
                                    with rouge_col1: 
                                        st.metric("ROUGE-1", f"{result['rouge_scores'].get('rouge1', 0):.3f}",
                                                 help="Measures word overlap")
                                    with rouge_col2: 
                                        st.metric("ROUGE-2", f"{result['rouge_scores'].get('rouge2', 0):.3f}",
                                                 help="Measures bigram overlap")
                                    with rouge_col3: 
                                        st.metric("ROUGE-L", f"{result['rouge_scores'].get('rougeL', 0):.3f}",
                                                 help="Measures longest common subsequence")
                                    
                                    # Show visualization using the correct method
                                    try:
                                        img_str = ai_processor.create_rouge_visualization(result['rouge_scores'])
                                        if img_str:
                                            st.image(f"data:image/png;base64,{img_str}", use_container_width=True)
                                        else:
                                            st.info("📈 Visualization not available")
                                    except Exception as viz_error:
                                        st.warning(f"Visualization error: {viz_error}")
                                else:
                                    st.warning("ROUGE scores not available for this summary")
                                
                                # Show remaining models
                                remaining = result.get('remaining_models', [])
                                if remaining:
                                    st.info(f"🔄 Next model: {remaining[0].upper()}")
                                else:
                                    st.info("🔄 All models used! Will restart from BART.")
                                
                        except Exception as e:
                            st.error(f"AI summarization error: {e}")
                else:
                    st.warning("Please enter some text to summarize.")
            
            # Add reset button
            if st.button("🔄 Reset Model Rotation", key="reset_models"):
                ai_processor.reset_user_models(st.session_state.user_id)
                st.success("Model rotation reset! Next model: BART")
                st.rerun()
        
        with tab2:
            st.subheader("🔄 AI Paraphrasing")
            st.info("🎯 Choose from different models with complexity control")
            
            # File upload for paraphrasing
            st.subheader("📁 Upload File for Paraphrasing")
            para_uploaded_file = st.file_uploader("Choose a file", type=['txt', 'pdf', 'docx'], key="para_file_uploader")
            
            para_extracted_text = ""
            if para_uploaded_file is not None:
                para_extracted_text = extract_text_from_file(para_uploaded_file)
                if para_extracted_text:
                    st.success("✅ File uploaded successfully!")
                    with st.expander("View Extracted Text"):
                        st.text_area("Text", para_extracted_text, height=150, disabled=True, key="para_extracted_text")
            
            # Direct text input for paraphrasing
            st.subheader("📝 Or Enter Text Directly")
            para_direct_text = st.text_area("Paste your text for paraphrasing:", height=150, key="para_text")
            
            para_final_text = para_extracted_text if para_extracted_text else para_direct_text
            
            # Model selection for paraphrasing
            para_model = st.selectbox(
                "Choose Paraphrase Model:",
                ["humarin-t5-base", "t5-large"],
                help="humarin-t5-base: ChatGPT-style paraphrasing, t5-large: General purpose paraphrasing"
            )
            
            # Complexity level with better descriptions
            complexity_level = st.select_slider(
                "Paraphrase Complexity:",
                options=["simple", "medium", "advanced", "creative"],
                value="medium",
                help="Simple: Easier language, Medium: Balanced approach, Advanced: Complex vocabulary, Creative: Most creative rewriting"
            )
            
            # Show complexity descriptions
            with st.expander("ℹ️ Complexity Level Details"):
                st.markdown("""
                - **Simple**: Uses simpler language with basic vocabulary
                - **Medium**: Balanced approach with clear phrasing
                - **Advanced**: More complex vocabulary and sentence structures
                - **Creative**: Most creative rewriting while preserving meaning
                """)
            
            if st.button("Paraphrase Text", key="paraphrase_btn", type="primary"):
                if para_final_text.strip():
                    with st.spinner("Paraphrasing with AI..."):
                        try:
                            result = ai_processor.paraphrase(para_final_text, complexity_level, para_model, st.session_state.user_id, st.session_state.user_id)
                            
                            if 'error' in result:
                                st.error(f"Paraphrasing failed: {result['error']}")
                            else:
                                st.success(f"✅ Text paraphrased using {result['model_used']}!")
                                
                                # Show paraphrased text
                                st.text_area("Paraphrased Text", result['paraphrased'], height=150, key="para_output")
                                
                                # Show metrics
                                col1, col2, col3 = st.columns(3)
                                with col1:
                                    st.metric("Similarity", f"{result.get('similarity_score', 0.5):.0%}")
                                with col2:
                                    st.metric("Original Words", result.get('original_length', 0))
                                with col3:
                                    st.metric("New Words", result.get('paraphrased_length', 0))
                                
                                # Show complexity impact
                                st.info(f"Complexity Level: **{result['complexity'].upper()}**")
                                
                                # Side-by-side comparison
                                st.subheader("🆚 Comparison")
                                comp_col1, comp_col2 = st.columns(2)
                                with comp_col1: 
                                    st.text_area("Original", para_final_text, height=100, disabled=True)
                                with comp_col2: 
                                    st.text_area("Paraphrased", result['paraphrased'], height=100, disabled=True)
                                
                                # Show differences
                                if result.get('similarity_score', 1) < 0.9:
                                    st.success("✅ Significant paraphrasing detected!")
                                else:
                                    st.warning("⚠️ Minimal changes detected. Try a different complexity level or model.")
                                
                        except Exception as e:
                            st.error(f"Paraphrasing error: {e}")
                else:
                    st.warning("Please enter some text to paraphrase.")
        
        # Add recent activity section with improved error handling and visualization
        st.markdown("---")
        st.subheader("📊 Recent Activity")
        try:
            headers = {"Authorization": f"Bearer {st.session_state.token}"}
            response = httpx.get(f"{BACKEND_URL}/recent-activity", headers=headers)
            if response.status_code == 200:
                activity_data = response.json()
                if not activity_data:
                    st.info("No recent activity found. Your summaries and paraphrases will appear here.")
                else:
                    # Create a DataFrame for better display
                    activity_list = []
                    for activity in activity_data:
                        activity_type = activity['type']
                        timestamp = activity['timestamp']
                        model = activity['model_used']
                        preview = activity['preview']
                        if activity_type == 'summarization':
                            activity_list.append({
                                'Type': '📝 Summarization',
                                'Timestamp': timestamp,
                                'Model': model.upper(),
                                'Preview': preview,
                                'ROUGE-1': activity.get('rouge1_score', 0),
                                'ROUGE-2': activity.get('rouge2_score', 0),
                                'ROUGE-L': activity.get('rougeL_score', 0),
                                'Complexity': None,
                                'Similarity': None,
                                'Original Words': None,
                                'New Words': None
                            })
                        else:
                            activity_list.append({
                                'Type': '🔄 Paraphrasing',
                                'Timestamp': timestamp,
                                'Model': model.upper(),
                                'Preview': preview,
                                'ROUGE-1': None,
                                'ROUGE-2': None,
                                'ROUGE-L': None,
                                'Complexity': activity.get('complexity_level', 'medium'),
                                'Similarity': activity.get('similarity_score', 0),
                                'Original Words': activity.get('original_length', 0),
                                'New Words': activity.get('paraphrased_length', 0)
                            })
                    # Display as a nice table
                    df = pd.DataFrame(activity_list)
                    st.dataframe(df, use_container_width=True, hide_index=True)
                    
                    # Visualize paraphrasing metrics if available
                    para_df = df[df['Type'] == '🔄 Paraphrasing']
                    if not para_df.empty:
                        st.subheader("🔬 Paraphrasing Metrics Visualization")
                        fig, ax = plt.subplots(figsize=(8, 4))
                        ax.bar(para_df['Timestamp'], para_df['Similarity'], color='#2563EB', label='Similarity (%)')
                        ax.plot(para_df['Timestamp'], para_df['Original Words'], color='#F59E0B', marker='o', label='Original Words')
                        ax.plot(para_df['Timestamp'], para_df['New Words'], color='#22C55E', marker='o', label='New Words')
                        ax.set_ylabel("Value")
                        ax.set_xlabel("Timestamp")
                        ax.set_title("Similarity & Word Counts (Recent Paraphrasing)")
                        ax.legend()
                        plt.xticks(rotation=45)
                        plt.tight_layout()
                        st.pyplot(fig)
            else:
                st.error("Could not fetch recent activity. Please check your backend and authentication.")
        except Exception as e:
            st.error(f"Error loading activity: {e}")

# Logout and status
if st.session_state.logged_in:
    st.sidebar.success(f"✅ Logged In as {st.session_state.user_id}")
    if st.sidebar.button("🚪 Logout", key="logout_btn"):
        st.session_state.logged_in = False
        st.session_state.token = None
        st.session_state.profile_image = None
        st.session_state.user_id = None
        st.session_state.menu = "Login"
        st.rerun()
    
    st.sidebar.header("Quick Access")
    if st.sidebar.button("📊 Text Analysis", key="nav_analysis"):
        st.session_state.menu = "Text Analysis"
        st.rerun()
    if st.sidebar.button("🧠 AI Studio", key="nav_studio"):
        st.session_state.menu = "AI Studio"
        st.rerun()
    if st.sidebar.button("👤 Profile", key="nav_profile"):
        st.session_state.menu = "Profile"
        st.rerun()
else:
    st.info("👈 Please login from the sidebar to access advanced AI features!")


#uvicorn backend.authentication:app --reload
#then run the frontend with:
#streamlit run frontend/interface.py