from ai_models import ai_processor

def test_sequential_summarization():
    print("\nTesting Automatic Sequential Model Access...")
    
    test_text = """
    Artificial intelligence is transforming many aspects of society. Machine learning algorithms 
    can now recognize patterns and make predictions with remarkable accuracy. Deep learning models 
    have achieved breakthrough performance in image recognition, natural language processing, 
    and many other domains. However, these systems also raise important ethical questions about 
    privacy, bias, and accountability that society must address.
    """
    
    user_id = "test_user_1"
    
    # Test getting summaries from all models sequentially
    print("=== SEQUENTIAL SUMMARIZATION TEST ===")
    for i in range(4):  # Try 4 times (will cycle through 3 models)
        print(f"\n--- Attempt {i+1} ---")
        result = ai_processor.summarize(test_text, user_id, 'medium')
        print(f"Model: {result['model_used']}")
        print(f"Summary: {result['summary']}")
        print(f"ROUGE Scores: {result['rouge_scores']}")
        print(f"Remaining models: {result['remaining_models']}")
        
        if i < 3:  # Simulate user wanting to try another model
            print("→ Simulating user request for another model...")

def test_paraphrasing():
    print("\n=== PARAPHRASING TEST ===")
    test_text = "The quick brown fox jumps over the lazy dog."
    
    for complexity in ['simple', 'medium', 'advanced']:
        result = ai_processor.paraphrase(test_text, complexity)
        print(f"{complexity.upper()}: {result['paraphrased']}")

def test_gpu_status():
    print("\n=== GPU STATUS ===")
    import torch
    if torch.cuda.is_available():
        print(f"✅ GPU Available: {torch.cuda.get_device_name(0)}")
        print(f"✅ GPU Memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
    else:
        print("⚠️  No GPU available, using CPU")

if __name__ == "__main__":
    test_gpu_status()
    test_sequential_summarization()
    test_paraphrasing()