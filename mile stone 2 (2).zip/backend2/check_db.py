import sqlite3
import pandas as pd
from tabulate import tabulate
import os
from datetime import datetime

def view_database():
    try:
        # Path is now backend/data/app.db
        db_path = os.path.join(os.path.dirname(__file__), 'data', 'app.db')
        if not os.path.exists(db_path):
            print(f"❌ Database file '{db_path}' does not exist!")
            print("💡 Run 'python database.py' first to create the database.")
            return
        
        conn = sqlite3.connect(db_path)
        
        # Get current timestamp
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        print("🔍 TEXT PROCESSING APPLICATION - DATABASE VIEWER")
        print(f"Database: {db_path}")
        print(f"Timestamp: {current_time}")
        print("\n📊 DATABASE CONTENTS:\n")
        
        # Get overall statistics
        cursor = conn.cursor()
        
        # User count
        cursor.execute("SELECT COUNT(*) FROM users")
        total_users = cursor.fetchone()[0]
        
        # Session count (approximated by unique user-timestamp combinations)
        cursor.execute("""
            SELECT COUNT(DISTINCT user_id || '-' || DATE(timestamp)) 
            FROM (
                SELECT user_id, timestamp FROM summarization_logs 
                UNION ALL 
                SELECT user_id, timestamp FROM paraphrasing_logs
            )
        """)
        total_sessions = cursor.fetchone()[0]
        
        # Request counts
        cursor.execute("SELECT COUNT(*) FROM summarization_logs")
        total_summarizations = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM paraphrasing_logs")
        total_paraphrases = cursor.fetchone()[0]
        
        total_requests = total_summarizations + total_paraphrases
        
        # Success counts
        cursor.execute("SELECT COUNT(*) FROM summarization_logs WHERE status = 'success'")
        successful_summarizations = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM paraphrasing_logs WHERE status = 'success'")
        successful_paraphrases = cursor.fetchone()[0]
        
        successful_requests = successful_summarizations + successful_paraphrases
        success_rate = (successful_requests / total_requests * 100) if total_requests > 0 else 0
        
        # Average processing time
        cursor.execute("SELECT AVG(processing_time_ms) FROM summarization_logs")
        avg_summary_time = cursor.fetchone()[0] or 0
        
        cursor.execute("SELECT AVG(processing_time_ms) FROM paraphrasing_logs")
        avg_paraphrase_time = cursor.fetchone()[0] or 0
        
        avg_processing_time = (avg_summary_time * total_summarizations + avg_paraphrase_time * total_paraphrases) / total_requests if total_requests > 0 else 0
        
        # Model usage statistics
        cursor.execute("""
            SELECT model_used, 'summarization' as type, COUNT(*), AVG(processing_time_ms)
            FROM summarization_logs 
            GROUP BY model_used
            UNION ALL
            SELECT model_used, 'paraphrasing' as type, COUNT(*), AVG(processing_time_ms)
            FROM paraphrasing_logs 
            GROUP BY model_used
            ORDER BY type, COUNT(*) DESC
        """)
        model_stats = cursor.fetchall()
        
        # Print system statistics
        print("=" * 80)
        print(" " * 30 + "SYSTEM STATISTICS")
        print("=" * 80)
        
        print("OVERALL STATISTICS:")
        print(f"  Total Users: {total_users}")
        print(f"  Total Sessions: {total_sessions}")
        print(f"  Total Requests: {total_requests}")
        print(f"  Successful Requests: {successful_requests}")
        print(f"  Success Rate: {success_rate:.1f}%")
        print(f"  Average Processing Time: {avg_processing_time:.2f}ms\n")
        
        print("MODEL USAGE STATISTICS:")
        print(f"{'Model Name':<20} {'Type':<15} {'Usage Count':<12} {'Avg Time(ms)':<15}")
        print("-" * 62)
        
        for model, mtype, count, avg_time in model_stats:
            print(f"{model:<20} {mtype:<15} {count:<12} {avg_time or 0:<15.2f}")
        
        print("\n" + "=" * 80)
        print(" " * 35 + "USERS")
        print("=" * 80)
        
        # Get users data
        users_df = pd.read_sql_query("SELECT id, username, email, created_at FROM users ORDER BY id", conn)
        if not users_df.empty:
            print(tabulate(users_df, headers='keys', tablefmt='grid', showindex=False))
            print(f"\nTotal Users: {len(users_df)}")
        else:
            print("No users found")
        
        print("\n" + "=" * 80)
        print(" " * 25 + "SUMMARIZATION LOGS")
        print("=" * 80)
        
        # Get summarization logs with text previews
        cursor.execute("""
            SELECT id, username, model_used, length_setting, complexity_level,
                   substr(original_text, 1, 50) || '...' as original_preview,
                   substr(summary_text, 1, 50) || '...' as summary_preview,
                   processing_time_ms, rouge1_score, timestamp
            FROM summarization_logs 
            ORDER BY timestamp DESC
        """)
        summarization_logs = cursor.fetchall()
        
        if summarization_logs:
            summarization_df = pd.DataFrame(summarization_logs, columns=[
                'ID', 'Username', 'Model', 'Length', 'Complexity', 
                'Original Text', 'Summary', 'Time(ms)', 'ROUGE-1', 'Timestamp'
            ])
            print(tabulate(summarization_df, headers='keys', tablefmt='grid', showindex=False))
        else:
            print("No summarization logs found")
        
        print("\n" + "=" * 80)
        print(" " * 25 + "PARAPHRASING LOGS")
        print("=" * 80)
        
        # Get paraphrasing logs with text previews
        cursor.execute("""
            SELECT id, username, model_used, complexity_level,
                   substr(original_text, 1, 50) || '...' as original_preview,
                   substr(paraphrased_text, 1, 50) || '...' as paraphrased_preview,
                   processing_time_ms, similarity_score, timestamp
            FROM paraphrasing_logs 
            ORDER BY timestamp DESC
        """)
        paraphrasing_logs = cursor.fetchall()
        
        if paraphrasing_logs:
            paraphrasing_df = pd.DataFrame(paraphrasing_logs, columns=[
                'ID', 'Username', 'Model', 'Complexity', 
                'Original Text', 'Paraphrased Text', 'Time(ms)', 'Similarity', 'Timestamp'
            ])
            print(tabulate(paraphrasing_df, headers='keys', tablefmt='grid', showindex=False))
        else:
            print("No paraphrasing logs found")
        
        conn.close()
        
    except Exception as e:
        print(f"❌ Error connecting to database: {e}")
        print("💡 Make sure you're running this from the project root directory")

if __name__ == "__main__":
    view_database()