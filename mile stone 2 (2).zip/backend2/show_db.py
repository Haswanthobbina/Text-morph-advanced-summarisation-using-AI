import sqlite3
from passlib.context import CryptContext
import os
from datetime import datetime

def show_detailed_database():
    pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
    
    # Path is now backend/data/app.db
    db_path = os.path.join(os.path.dirname(__file__), 'data', 'app.db')
    if not os.path.exists(db_path):
        print(f"❌ Database file '{db_path}' does not exist!")
        print("💡 Run 'python database.py' first to create the database.")
        return
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    print("=" * 80)
    print(" " * 20 + "DETAILED DATABASE VIEW")
    print("=" * 80)
    print(f"Timestamp: {current_time}\n")
    
    # Show all users
    print("👥 USERS TABLE:")
    cursor.execute("SELECT id, username, email, password_hash, created_at FROM users")
    users = cursor.fetchall()
    for user in users:
        print(f"ID: {user[0]}, Username: {user[1]}, Email: {user[2]}")
        print(f"Password Hash: {user[3][:30]}... (securely hashed with bcrypt)")
        print(f"Created At: {user[4]}")
        print("-" * 60)
    
    # Show detailed summarization logs
    print("\n📝 DETAILED SUMMARIZATION LOGS:")
    cursor.execute("""
        SELECT id, username, model_used, length_setting, complexity_level,
               original_text, summary_text, processing_time_ms, 
               rouge1_score, rouge2_score, rougeL_score, timestamp
        FROM summarization_logs 
        ORDER BY timestamp DESC
    """)
    summarizations = cursor.fetchall()
    
    for log in summarizations:
        print(f"\n🔹 Summarization ID: {log[0]}")
        print(f"   User: {log[1]}, Model: {log[2]}")
        print(f"   Length: {log[3]}, Complexity: {log[4]}")
        print(f"   Processing Time: {log[7]}ms")
        print(f"   ROUGE Scores: {log[8]:.3f}, {log[9]:.3f}, {log[10]:.3f}")
        print(f"   Timestamp: {log[11]}")
        print(f"   Original Text: {log[5][:100]}...")
        print(f"   Summary: {log[6]}")
        print("-" * 60)
    
    # Show detailed paraphrasing logs
    print("\n🔄 DETAILED PARAPHRASING LOGS:")
    cursor.execute("""
        SELECT id, username, model_used, complexity_level,
               original_text, paraphrased_text, processing_time_ms, 
               similarity_score, timestamp
        FROM paraphrasing_logs 
        ORDER BY timestamp DESC
    """)
    paraphrases = cursor.fetchall()
    
    for log in paraphrases:
        print(f"\n🔹 Paraphrasing ID: {log[0]}")
        print(f"   User: {log[1]}, Model: {log[2]}")
        print(f"   Complexity: {log[3]}")
        print(f"   Processing Time: {log[6]}ms")
        print(f"   Similarity Score: {log[7]:.3f}")
        print(f"   Timestamp: {log[8]}")
        print(f"   Original Text: {log[4][:100]}...")
        print(f"   Paraphrased Text: {log[5]}")
        print("-" * 60)
    
    conn.close()
    print("\n✅ Detailed database view complete!")

if __name__ == "__main__":
    show_detailed_database()