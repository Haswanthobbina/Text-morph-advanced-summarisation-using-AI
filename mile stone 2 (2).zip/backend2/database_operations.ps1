# PowerShell script for Text-Morph database operations
# This script provides easy commands to manage the SQLite database

param(
    [Parameter(Position=0)]
    [ValidateSet("init", "view", "setup", "clean")]
    [string]$Action = "view"
)

Write-Host "Text-Morph Database Operations" -ForegroundColor Cyan
Write-Host "=================================" -ForegroundColor Cyan

switch ($Action) {
    "init" {
        Write-Host "Initializing database..." -ForegroundColor Yellow
        python database.py
        if ($LASTEXITCODE -eq 0) {
            Write-Host "Database initialized successfully!" -ForegroundColor Green
        } else {
            Write-Host "Database initialization failed!" -ForegroundColor Red
        }
    }
    
    "setup" {
        Write-Host "Setting up database with sample data..." -ForegroundColor Yellow
        python setup_db.py
        if ($LASTEXITCODE -eq 0) {
            Write-Host "Database setup completed!" -ForegroundColor Green
        } else {
            Write-Host "Database setup failed!" -ForegroundColor Red
        }
    }
    
    "view" {
        Write-Host "Viewing database contents..." -ForegroundColor Yellow
        python check_db.py
    }
    
    "clean" {
        Write-Host "Cleaning database..." -ForegroundColor Yellow
        $dbPath = "data\app.db"
        if (Test-Path $dbPath) {
            Remove-Item $dbPath -Force
            Write-Host "Database cleaned!" -ForegroundColor Green
        } else {
            Write-Host "Database file not found - nothing to clean." -ForegroundColor Blue
        }
    }
    
    default {
        Write-Host "Usage: .\database_operations.ps1 [init|setup|view|clean]" -ForegroundColor White
        Write-Host ""
        Write-Host "Commands:" -ForegroundColor White
        Write-Host "  init  - Initialize empty database with tables" -ForegroundColor Gray
        Write-Host "  setup - Initialize database and add sample data" -ForegroundColor Gray
        Write-Host "  view  - Display database contents (default)" -ForegroundColor Gray
        Write-Host "  clean - Remove database file" -ForegroundColor Gray
    }
}

Write-Host ""
