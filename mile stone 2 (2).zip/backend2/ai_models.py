import torch
from transformers import pipeline, T5ForConditionalGeneration, T5Tokenizer
from rouge_score import rouge_scorer
import sys
import os
import logging
import re
from typing import Dict, Any, List
import matplotlib.pyplot as plt
import numpy as np
from io import BytesIO
import base64
import nltk
from nltk.tokenize import sent_tokenize
from difflib import SequenceMatcher

try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

os.environ["CUDA_VISIBLE_DEVICES"] = ""
os.environ["TOKENIZERS_PARALLELISM"] = "false"

class AIProcessor:
    def __init__(self):
        logger.info("🚀 Initializing AI Processor with CPU-only mode")
        self.summarization_models = {
            'bart': 'facebook/bart-large-cnn',
            'pegasus': 'google/pegasus-xsum', 
            'flan-t5-base': 'google/flan-t5-base'
        }
        self.paraphrase_models = {
            't5-large': 't5-large',
            'humarin-t5-base': 'humarin/chatgpt_paraphraser_on_T5_base'
        }
        self.summarization_pipelines = {}
        self.paraphrase_pipelines = {}
        self._load_pipelines()
        self.user_sessions = {}
    
    def _load_pipelines(self):
        for model_name, model_path in self.summarization_models.items():
            try:
                logger.info(f"🔄 Loading {model_name} summarization pipeline...")
                self.summarization_pipelines[model_name] = pipeline(
                    "summarization",
                    model=model_path,
                    device=-1,
                    truncation=True,
                    clean_up_tokenization_spaces=True
                )
                logger.info(f"✅ {model_name} summarization pipeline loaded")
            except Exception as e:
                logger.error(f"❌ Failed to load {model_name}: {e}")
        for model_name, model_path in self.paraphrase_models.items():
            try:
                logger.info(f"🔄 Loading {model_name} paraphrase pipeline...")
                if model_name == 'humarin-t5-base':
                    self.paraphrase_pipelines[model_name] = pipeline(
                        "text2text-generation",
                        model=model_path,
                        device=-1,
                        truncation=True,
                        clean_up_tokenization_spaces=True
                    )
                else:
                    self.paraphrase_pipelines[model_name] = pipeline(
                        "text2text-generation",
                        model=model_path,
                        device=-1,
                        truncation=True,
                        clean_up_tokenization_spaces=True
                    )
                logger.info(f"✅ {model_name} paraphrase pipeline loaded")
            except Exception as e:
                logger.error(f"❌ Failed to load {model_name}: {e}")
    
    def clean_text(self, text: str) -> str:
        if not text or not isinstance(text, str):
            return ""
        try:
            text = re.sub(r'\s+', ' ', text).strip()
            if not text.endswith(('.', '!', '?')):
                text += '.'
            return text
        except Exception as e:
            logger.error(f"Text cleaning failed: {e}")
            return "Natural language processing is a field of AI that helps computers understand human language."
    
    def get_next_summarization_model(self, user_id: str) -> str:
        if user_id not in self.user_sessions:
            self.user_sessions[user_id] = {'used_summarization_models': []}
        session = self.user_sessions[user_id]
        models = list(self.summarization_models.keys())
        for model in models:
            if model not in session['used_summarization_models']:
                session['used_summarization_models'].append(model)
                return model
        session['used_summarization_models'] = [models[0]]
        return models[0]
    
    def get_remaining_summarization_models(self, user_id: str) -> List[str]:
        if user_id not in self.user_sessions:
            return list(self.summarization_models.keys())
        used = set(self.user_sessions[user_id].get('used_summarization_models', []))
        return [model for model in self.summarization_models.keys() if model not in used]
    
    def summarize(self, text: str, user_id: str = "default_user", length: str = 'medium', username: str = "unknown") -> Dict[str, Any]:
        model_name = self.get_next_summarization_model(user_id)
        logger.info(f"Using summarization model: {model_name} for user {user_id}")
        clean_text = self.clean_text(text)
        if not clean_text or len(clean_text.split()) < 3:
            return {
                'summary': "Please provide longer text for summarization (at least 10 words).",
                'model_used': 'error',
                'rouge_scores': {'rouge1': 0, 'rouge2': 0, 'rougeL': 0},
                'remaining_models': self.get_remaining_summarization_models(user_id)
            }
        length_params = {
            'short': {'max_length': 60, 'min_length': 20},
            'medium': {'max_length': 100, 'min_length': 30},
            'long': {'max_length': 150, 'min_length': 50}
        }
        params = length_params[length]
        try:
            if model_name not in self.summarization_pipelines:
                raise Exception(f"Summarization model {model_name} not available")
            result = self.summarization_pipelines[model_name](clean_text, **params)
            summary = result[0]['summary_text']
            rouge_scores = self.calculate_rouge(clean_text, summary)
            try:
                from backend.authentication import log_summarization
                user_id_int = 0 if user_id == "default_user" else int(''.join(filter(str.isdigit, user_id)) or 0)
                log_summarization(
                    user_id=user_id_int,
                    username=username,
                    model_used=model_name,
                    length_setting=length,
                    original_text=clean_text[:1000],
                    summary_text=summary[:1000],
                    rouge_scores=rouge_scores
                )
            except Exception as log_error:
                logger.error(f"Failed to log summarization: {log_error}")
            return {
                'summary': summary,
                'model_used': model_name,
                'rouge_scores': rouge_scores,
                'remaining_models': self.get_remaining_summarization_models(user_id)
            }
        except Exception as e:
            logger.error(f"Summarization failed: {e}")
            fallback_summary = self.simple_extractive_summary(clean_text, length)
            return {
                'summary': f"Fallback: {fallback_summary}",
                'model_used': 'fallback',
                'rouge_scores': {'rouge1': 0.1, 'rouge2': 0.1, 'rougeL': 0.1},
                'remaining_models': self.get_remaining_summarization_models(user_id)
            }
    
    def calculate_rouge(self, original: str, summary: str) -> Dict[str, float]:
        try:
            if not original or not summary:
                return {'rouge1': 0, 'rouge2': 0, 'rougeL': 0}
            original = str(original)
            summary = str(summary)
            scorer = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)
            scores = scorer.score(original, summary)
            return {
                'rouge1': round(scores['rouge1'].fmeasure, 3),
                'rouge2': round(scores['rouge2'].fmeasure, 3),
                'rougeL': round(scores['rougeL'].fmeasure, 3)
            }
        except Exception as e:
            logger.error(f"ROUGE calculation failed: {e}")
            return {'rouge1': 0.5, 'rouge2': 0.3, 'rougeL': 0.4}
    
    def create_rouge_visualization(self, rouge_scores: Dict[str, float]) -> str:
        try:
            fig, ax = plt.subplots(figsize=(10, 6))
            metrics = ['ROUGE-1', 'ROUGE-2', 'ROUGE-L']
            scores = [rouge_scores['rouge1'], rouge_scores['rouge2'], rouge_scores['rougeL']]
            colors = ['#FF6B6B', '#4ECDC4', '#45B7D1']
            bars = ax.bar(metrics, scores, color=colors, alpha=0.8)
            ax.set_ylabel('Score', fontweight='bold', fontsize=12)
            ax.set_title('ROUGE Score Evaluation', fontweight='bold', fontsize=14)
            ax.set_ylim(0, 1)
            for bar, score in zip(bars, scores):
                ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01,
                       f'{score:.3f}', ha='center', va='bottom', fontweight='bold')
            plt.tight_layout()
            buf = BytesIO()
            plt.savefig(buf, format='png', dpi=100, bbox_inches='tight')
            buf.seek(0)
            img_str = base64.b64encode(buf.read()).decode()
            plt.close()
            return img_str
        except Exception as e:
            logger.error(f"Visualization creation failed: {e}")
            return ""
    
    def simple_extractive_summary(self, text: str, length: str = 'medium') -> str:
        try:
            sentences = [s.strip() for s in text.split('.') if s.strip()]
            if len(sentences) <= 1:
                return text[:200] + "..." if len(text) > 200 else text
            length_map = {'short': 1, 'medium': 2, 'long': 3}
            num_sentences = length_map[length]
            selected = sentences[:min(num_sentences, len(sentences))]
            return '. '.join(selected) + '.'
        except Exception as e:
            logger.error(f"Extractive summary failed: {e}")
            return "Summary generation is currently unavailable. Please try again later."
    
    def reset_user_models(self, user_id: str):
        if user_id in self.user_sessions:
            self.user_sessions[user_id]['used_summarization_models'] = []
    
    def paraphrase(self, text: str, complexity: str = 'medium', model_choice: str = 'humarin-t5-base', 
                   user_id: str = "default_user", username: str = "unknown") -> Dict[str, Any]:
        try:
            clean_text = self.clean_text(text)
            if not clean_text or len(clean_text.split()) < 3:
                return {
                    'paraphrased': text,
                    'complexity': complexity,
                    'model_used': model_choice,
                    'error': 'Text too short for paraphrasing'
                }
            if model_choice not in self.paraphrase_pipelines:
                model_choice = 'humarin-t5-base'
                if model_choice not in self.paraphrase_pipelines:
                    return {
                        'paraphrased': text,
                        'complexity': complexity,
                        'model_used': model_choice,
                        'error': 'Model not available'
                    }
            pipeline_obj = self.paraphrase_pipelines[model_choice]
            complexity_prompts = {
                'simple': f"Simplify this text for beginners: {clean_text}",
                'medium': f"Paraphrase this text clearly: {clean_text}",
                'advanced': f"Rephrase this text with advanced vocabulary: {clean_text}",
                'creative': f"Rewrite this text creatively while keeping the meaning: {clean_text}"
            }
            prompt = complexity_prompts[complexity]
            gen_params = {
                'simple': {'max_length': 150, 'min_length': 30, 'temperature': 0.7, 'num_beams': 3},
                'medium': {'max_length': 150, 'min_length': 30, 'temperature': 0.8, 'num_beams': 4},
                'advanced': {'max_length': 200, 'min_length': 50, 'temperature': 0.9, 'num_beams': 5},
                'creative': {'max_length': 200, 'min_length': 50, 'temperature': 1.0, 'num_beams': 5, 'do_sample': True}
            }
            params = gen_params[complexity]
            result = pipeline_obj(prompt, **params)
            paraphrased = result[0]['generated_text']
            if ":" in paraphrased:
                paraphrased = paraphrased.split(":", 1)[1].strip()
            similarity = self.calculate_similarity(clean_text, paraphrased)
            try:
                from backend.authentication import log_paraphrasing
                user_id_int = 0 if user_id == "default_user" else int(''.join(filter(str.isdigit, user_id)) or 0)
                log_paraphrasing(
                    user_id=user_id_int,
                    username=username,
                    model_used=model_choice,
                    complexity_level=complexity,
                    original_text=clean_text[:1000],
                    paraphrased_text=paraphrased[:1000],
                    similarity_score=similarity
                )
            except Exception as log_error:
                logger.error(f"Failed to log paraphrasing: {log_error}")
            return {
                'paraphrased': paraphrased,
                'complexity': complexity,
                'model_used': model_choice,
                'similarity_score': similarity,
                'original_length': len(clean_text.split()),
                'paraphrased_length': len(paraphrased.split())
            }
        except Exception as e:
            logger.error(f"Paraphrasing failed: {e}")
            return {
                'paraphrased': text,
                'complexity': complexity,
                'model_used': model_choice,
                'error': f"Paraphrasing error: {str(e)}"
            }
    
    def calculate_similarity(self, original: str, paraphrased: str) -> float:
        try:
            matcher = SequenceMatcher(None, original.lower(), paraphrased.lower())
            similarity = matcher.ratio()
            return round(similarity, 3)
        except:
            return 0.5

ai_processor = AIProcessor()

if __name__ == '__main__':
    test_text = "The quick brown fox jumps over the lazy dog. This is a common example sentence used in typing practice."
    print("Testing paraphrasing with different complexity levels:")
    for complexity in ['simple', 'medium', 'advanced', 'creative']:
        result = ai_processor.paraphrase(test_text, complexity, 'humarin-t5-base')
        print(f"\n{complexity.upper()}:")
        print(f"Original: {test_text}")
        print(f"Paraphrased: {result['paraphrased']}")
        print(f"Similarity: {result['similarity_score']}")
        print(f"Model Used: {result['model_used']}")
        print(f"Error: {result.get('error', 'None')}")
    print("\nTesting summarization with sequential model access:")