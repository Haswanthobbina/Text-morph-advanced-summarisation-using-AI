# Text-Morph Database Guide

This guide explains how to set up and manage the SQLite database for the Text-Morph application.

## 🗄️ Database Structure

The database contains the following tables:

- **users** - User account information (id, username, email, password_hash)
- **user_preferences** - User language and reading preferences
- **user_summarization_prefs** - User summarization settings
- **summarization_logs** - History of text summarization activities
- **paraphrasing_logs** - History of text paraphrasing activities

## 🚀 Quick Start

### Option 1: Using Python Scripts Directly

1. **Setup database with sample data:**
   ```bash
   python setup_db.py
   ```

2. **View database contents:**
   ```bash
   python check_db.py
   ```

3. **Initialize empty database only:**
   ```bash
   python database.py
   ```

### Option 2: Using PowerShell Script

1. **Setup database with sample data:**
   ```powershell
   .\database_operations.ps1 setup
   ```

2. **View database contents:**
   ```powershell
   .\database_operations.ps1 view
   .\database_operations.ps1        # (default action)
   ```

3. **Initialize empty database:**
   ```powershell
   .\database_operations.ps1 init
   ```

4. **Clean database:**
   ```powershell
   .\database_operations.ps1 clean
   ```

### Option 3: Using Batch File

1. **Setup database with sample data:**
   ```cmd
   database_operations.bat setup
   ```

2. **View database contents:**
   ```cmd
   database_operations.bat view
   database_operations.bat          # (default action)
   ```

3. **Show help:**
   ```cmd
   database_operations.bat help
   ```

## 📋 Sample Data

When you run the setup, the database is populated with:

- **3 sample users:**
  - john_doe (john@example.com)
  - jane_smith (jane@example.com)  
  - bob_wilson (bob@example.com)

- **Sample activity logs** for each user showing text summarization and paraphrasing activities

## 🔧 Manual Database Operations

### Adding Users Programmatically

```python
from database import add_sample_user, add_sample_logs

# Add a new user
user_id = add_sample_user('new_user', 'user@example.com', 'hashed_password')

# Add sample logs for the user
if user_id:
    add_sample_logs(user_id, 'new_user')
```

### Querying the Database

```python
import sqlite3
from database import get_db_path

conn = sqlite3.connect(get_db_path())
cursor = conn.cursor()

# Get all users
cursor.execute("SELECT * FROM users")
users = cursor.fetchall()

# Get user activity count
cursor.execute("""
    SELECT username, COUNT(*) as activities 
    FROM (
        SELECT username FROM summarization_logs 
        UNION ALL 
        SELECT username FROM paraphrasing_logs
    ) 
    GROUP BY username
""")
activity_counts = cursor.fetchall()

conn.close()
```

## 🐛 Troubleshooting

### Common Issues

1. **"Database file not found" error:**
   - Run `python setup_db.py` to create the database

2. **"ModuleNotFoundError: No module named 'pandas'" or similar:**
   - Install required dependencies: `pip install pandas tabulate`

3. **PowerShell execution policy errors:**
   - Run: `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope Process`

4. **Empty database or 0-byte file:**
   - Delete the `data/app.db` file and run setup again
   - Check that Python scripts complete without errors

### Database Location

The database file is located at:
```
backend2/data/app.db
```

### Required Dependencies

Make sure you have these Python packages installed:
```bash
pip install pandas tabulate
```

## 📊 Database Viewer Features

The `check_db.py` script provides:

- ✅ **Table structure display** - Shows column names and types
- ✅ **Formatted data tables** - Uses fancy grid formatting for better readability  
- ✅ **Smart text truncation** - Truncates long text fields in log tables
- ✅ **Summary statistics** - Shows user counts, activity counts, and most active users
- ✅ **Color-coded output** - Uses emojis and formatting for better visualization
- ✅ **Error handling** - Graceful handling of missing files and database errors

## 🔄 Database Schema Updates

If you need to modify the database schema:

1. Edit the table creation statements in `database.py`
2. Delete the existing database: `database_operations.ps1 clean`
3. Recreate with new schema: `database_operations.ps1 setup`

**Note:** This will remove all existing data. For production environments, use proper database migration scripts.
