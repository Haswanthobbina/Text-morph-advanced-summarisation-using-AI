import sqlite3
import os
import sys
from datetime import datetime

def init_db():
    # Path is now backend/data/app.db
    db_path = os.path.join(os.path.dirname(__file__), 'data', 'app.db')
    # Create data directory if it doesn't exist
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # User preferences table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_preferences (
            user_id INTEGER PRIMARY KEY,
            language TEXT DEFAULT 'en',
            reading_style TEXT DEFAULT 'neutral',
            content_type TEXT DEFAULT 'general',
            FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
        )
    ''')

    # User summarization preferences table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_summarization_prefs (
            user_id INTEGER PRIMARY KEY,
            summary_length TEXT DEFAULT 'medium',
            focus_area TEXT DEFAULT 'key_points',
            complexity_level TEXT DEFAULT 'medium',
            FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
        )
    ''')

    # Summarization logs table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS summarization_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            username TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            model_used TEXT,
            length_setting TEXT,
            complexity_level TEXT,
            original_text TEXT,
            summary_text TEXT,
            processing_time_ms INTEGER,
            rouge1_score REAL,
            rouge2_score REAL,
            rougeL_score REAL,
            status TEXT DEFAULT 'success',
            FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
        )
    ''')

    # Paraphrasing logs table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS paraphrasing_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            username TEXT,
            model_used TEXT,
            complexity_level TEXT,
            original_text TEXT,
            paraphrased_text TEXT,
            similarity_score REAL,
            original_length INTEGER,
            paraphrased_length INTEGER,
            timestamp TEXT
        )
    ''')

    # Insert sample data for demonstration
    cursor.execute("SELECT COUNT(*) FROM users")
    user_count = cursor.fetchone()[0]
    
    if user_count == 0:
        from passlib.context import CryptContext
        pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
        
        # Insert sample users
        sample_users = [
            ('john_doe', 'john@example.com', pwd_context.hash('password123')),
            ('jane_smith', 'jane@example.com', pwd_context.hash('password123')),
            ('admin_user', 'admin@example.com', pwd_context.hash('admin123'))
        ]
        
        for username, email, password_hash in sample_users:
            cursor.execute(
                "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)",
                (username, email, password_hash)
            )
            user_id = cursor.lastrowid
            
            # Insert preferences
            cursor.execute(
                "INSERT INTO user_preferences (user_id) VALUES (?)",
                (user_id,)
            )
            
            # Insert summarization preferences
            cursor.execute(
                "INSERT INTO user_summarization_prefs (user_id) VALUES (?)",
                (user_id,)
            )
        
        # Insert sample summarization logs
        sample_summarizations = [
            (1, 'john_doe', 'BERT-Summarizer', 'medium', 'medium', 
             'Artificial intelligence is transforming various industries by automating tasks and providing insights from large datasets. Machine learning, a subset of AI, enables systems to learn from data without explicit programming.',
             'AI automates tasks and provides insights through machine learning.', 245, 0.85, 0.72, 0.83),
            (1, 'john_doe', 'GPT-Summarizer', 'long', 'advanced', 
             'Climate change represents one of the most pressing challenges of our time. Rising global temperatures, melting polar ice caps, and increasing frequency of extreme weather events all point to the urgent need for action.',
             'Climate change is an urgent global challenge requiring immediate action due to rising temperatures and extreme weather.', 312, 0.78, 0.65, 0.75),
            (2, 'jane_smith', 'BERT-Summarizer', 'short', 'simple', 
             'Renewable energy sources like solar and wind power are becoming increasingly cost-effective and efficient. Many countries are investing heavily in these technologies to reduce carbon emissions.',
             'Solar and wind energy are cost-effective solutions reducing carbon emissions.', 198, 0.82, 0.68, 0.80)
        ]
        
        for log in sample_summarizations:
            cursor.execute('''
                INSERT INTO summarization_logs 
                (user_id, username, model_used, length_setting, complexity_level, 
                 original_text, summary_text, processing_time_ms, rouge1_score, rouge2_score, rougeL_score)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', log)
        
        # Insert sample paraphrasing logs
        sample_paraphrases = [
            (1, 'john_doe', 'T5-Paraphraser', 'advanced',
             'The company announced record profits for the fourth quarter, exceeding analyst expectations.',
             'The organization reported unprecedented earnings during Q4, surpassing projections from financial analysts.', 356, 0.92),
            (2, 'jane_smith', 'T5-Paraphraser', 'simple',
             'Researchers discovered a new species of deep-sea fish with bioluminescent capabilities.',
             'Scientists found a new kind of glowing fish that lives deep in the ocean.', 287, 0.88),
            (3, 'admin_user', 'T5-Paraphraser', 'medium',
             'The new policy aims to reduce carbon emissions by 50% within the next decade through various initiatives.',
             'A fresh policy seeks to cut carbon emissions in half over ten years using multiple strategies.', 321, 0.90)
        ]
        
        for log in sample_paraphrases:
            cursor.execute('''
                INSERT INTO paraphrasing_logs 
                (user_id, username, model_used, complexity_level, 
                 original_text, paraphrased_text, similarity_score, original_length, paraphrased_length, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', log)

    conn.commit()
    conn.close()
    return db_path

if __name__ == "__main__":
    db_path = init_db()
    print(f"✅ Database initialized successfully at: {db_path}")
    print("✅ All tables created with sample data.")
    sys.exit(0)