# backend/test_login.py
import sqlite3
from passlib.context import CryptContext
import secrets
import string

def test_register():
    pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
    conn = sqlite3.connect('data/app.db')
    cursor = conn.cursor()
    
    # Generate a more random user to avoid conflicts
    alphabet = string.ascii_letters + string.digits
    username = "testuser_" + ''.join(secrets.choice(alphabet) for i in range(5))
    email = f"{username}@test.com"
    password = "test123_password"
    
    hashed_password = pwd_context.hash(password)
    
    cursor.execute("INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)", (username, email, hashed_password))
    conn.commit()
    
    print(f"\n✅ Created test user: '{username}' with password '{password}'")
    conn.close()

def test_login():
    pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
    conn = sqlite3.connect('data/app.db')
    cursor = conn.cursor()
    
    # Get all users from database
    cursor.execute("SELECT username, password_hash FROM users")
    users = cursor.fetchall()
    
    print("\n🧪 TESTING LOGIN SYSTEM")
    print("=" * 50)
    
    for username, password_hash in users:
        print(f"\nTesting user: {username}")
        print(f"Stored hash: {password_hash}")
        
        # Test with correct password (you need to know what you used)
        test_password = input(f"Enter the password for '{username}': ")
        
        # Test verification
        is_valid = pwd_context.verify(test_password, password_hash)
        print(f"Password verification: {is_valid}")
        
        if not is_valid:
            print("❌ VERIFICATION FAILED")
            # Let's see what a new hash of the same password looks like
            new_hash = pwd_context.hash(test_password)
            print(f"New hash of same password: {new_hash}")
            print(f"Hashes match: {new_hash == password_hash}")
        else:
            print("✅ VERIFICATION SUCCESS!")
    
    conn.close()

if __name__ == "__main__":
    # Run registration test first to ensure there's a user to test.
    test_register()
    test_login()