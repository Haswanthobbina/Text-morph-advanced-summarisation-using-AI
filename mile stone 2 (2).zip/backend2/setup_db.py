#!/usr/bin/env python3
"""
Setup script to initialize the database and populate with sample data
"""

from database import init_db, populate_sample_data
import os

def main():
    print("🚀 Setting up Text-Morph Database...")
    
    # Initialize database
    print("📁 Initializing database...")
    init_db()
    
    # Add sample data
    print("📝 Adding sample data...")
    populate_sample_data()
    
    print("✅ Database setup complete!")
    print("🔍 Run 'python check_db.py' to view the database contents.")

if __name__ == "__main__":
    main()
