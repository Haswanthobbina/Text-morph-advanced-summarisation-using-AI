import os
import sqlite3
from datetime import datetime, timedelta
from typing import Optional
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import JWTError, jwt
from passlib.context import CryptContext
from backend.schemas import UserCreate, UserLogin, UserOut, UserProfile, UserProfileUpdate, UserPreferences, SummarizationPreferences

app = FastAPI()

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

SECRET_KEY = os.getenv("SECRET_KEY", "your-secret-key-here-change-in-production")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

def get_db():
    db_path = os.path.join(os.path.dirname(__file__), 'data', 'app.db')
    conn = sqlite3.connect(db_path)
    try:
        yield conn
    finally:
        conn.close()

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def get_current_user(token: str = Depends(oauth2_scheme), db: sqlite3.Connection = Depends(get_db)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authentication credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    cursor = db.cursor()
    cursor.execute("SELECT id, username, email FROM users WHERE username = ?", (username,))
    user_data = cursor.fetchone()
    if not user_data:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    return UserOut(id=user_data[0], username=user_data[1], email=user_data[2])

@app.post("/register")
def register(user: UserCreate, db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    
    cursor.execute("SELECT id FROM users WHERE username = ? OR email = ?", (user.username, user.email))
    existing_user = cursor.fetchone()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username or email already registered"
        )
    
    hashed_password = get_password_hash(user.password)
    cursor.execute(
        "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)",
        (user.username, user.email, hashed_password)
    )
    db.commit()
    
    return {"message": "User created successfully"}

@app.post("/token")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    
    print(f"🔐 LOGIN ATTEMPT - Username: {form_data.username}, Password: {form_data.password}")
    
    cursor.execute("SELECT id, username, email, password_hash FROM users WHERE username = ?", (form_data.username,))
    user_data = cursor.fetchone()
    
    if not user_data:
        print("❌ USER NOT FOUND")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    print(f"✅ USER FOUND: {user_data[1]}")
    print(f"🔑 Verifying password...")
    
    if not verify_password(form_data.password, user_data[3]):
        print("❌ PASSWORD VERIFICATION FAILED")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    print("✅ LOGIN SUCCESSFUL!")
    
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user_data[1]}, expires_delta=access_token_expires
    )
    
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/profile", response_model=UserProfile)
def get_profile(current_user: UserOut = Depends(get_current_user), db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    
    cursor.execute("SELECT language, reading_style, content_type FROM user_preferences WHERE user_id = ?", (current_user.id,))
    prefs_data = cursor.fetchone()
    
    cursor.execute("SELECT summary_length, focus_area, complexity_level FROM user_summarization_prefs WHERE user_id = ?", (current_user.id,))
    summarization_prefs_data = cursor.fetchone()
    
    if prefs_data:
        preferences = UserPreferences(language=prefs_data[0], reading_style=prefs_data[1], content_type=prefs_data[2])
    else:
        preferences = UserPreferences()
        cursor.execute(
            "INSERT INTO user_preferences (user_id, language, reading_style, content_type) VALUES (?, ?, ?, ?)",
            (current_user.id, preferences.language, preferences.reading_style, preferences.content_type)
        )
    
    if summarization_prefs_data:
        summarization_prefs = SummarizationPreferences(
            summary_length=summarization_prefs_data[0],
            focus_area=summarization_prefs_data[1],
            complexity_level=summarization_prefs_data[2]
        )
    else:
        summarization_prefs = SummarizationPreferences()
        cursor.execute(
            "INSERT INTO user_summarization_prefs (user_id, summary_length, focus_area, complexity_level) VALUES (?, ?, ?, ?)",
            (current_user.id, summarization_prefs.summary_length, summarization_prefs.focus_area, summarization_prefs.complexity_level)
        )
    
    db.commit()
    return UserProfile(user=current_user, preferences=preferences, summarization_prefs=summarization_prefs)

@app.put("/profile", response_model=UserProfile)
def update_profile(profile_update: UserProfileUpdate, current_user: UserOut = Depends(get_current_user), db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    
    if profile_update.email is not None:
        cursor.execute("UPDATE users SET email = ? WHERE id = ?", (profile_update.email, current_user.id))
    
    if profile_update.preferences is not None:
        prefs = profile_update.preferences
        cursor.execute('''
            INSERT INTO user_preferences (user_id, language, reading_style, content_type)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
            language=excluded.language,
            reading_style=excluded.reading_style,
            content_type=excluded.content_type
        ''', (current_user.id, prefs.language, prefs.reading_style, prefs.content_type))
    
    if profile_update.summarization_prefs is not None:
        summarization_prefs = profile_update.summarization_prefs
        cursor.execute('''
            INSERT INTO user_summarization_prefs (user_id, summary_length, focus_area, complexity_level)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
            summary_length=excluded.summary_length,
            focus_area=excluded.focus_area,
            complexity_level=excluded.complexity_level
        ''', (current_user.id, summarization_prefs.summary_length, summarization_prefs.focus_area, summarization_prefs.complexity_level))
    
    db.commit()
    # It's more efficient to call get_profile with the already-established dependency injections
    # rather than passing them as arguments.
    return get_profile(current_user=current_user, db=db)

def log_summarization(user_id: int, username: str, model_used: str, length_setting: str, 
                     original_text: str, summary_text: str, rouge_scores: dict):
    """Log summarization request to database"""
    try:
        db_path = os.path.join(os.path.dirname(__file__), 'data', 'app.db')
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO summarization_logs 
            (user_id, username, model_used, length_setting, original_text, summary_text, rouge1_score, rouge2_score, rougeL_score)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (user_id, username, model_used, length_setting, original_text, summary_text, 
              rouge_scores.get('rouge1', 0), rouge_scores.get('rouge2', 0), rouge_scores.get('rougeL', 0)))
        
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Error logging summarization: {e}")
        return False

def log_paraphrasing(user_id: int, username: str, model_used: str, complexity_level: str,
                    original_text: str, paraphrased_text: str, similarity_score: float,
                    original_length: int, paraphrased_length: int):
    """Log paraphrasing request to database"""
    try:
        db_path = os.path.join(os.path.dirname(__file__), 'data', 'app.db')
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute('''
            ALTER TABLE paraphrasing_logs ADD COLUMN original_length INTEGER
        ''')
    except sqlite3.OperationalError:
        pass  # Column already exists

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute('''
            ALTER TABLE paraphrasing_logs ADD COLUMN paraphrased_length INTEGER
        ''')
    except sqlite3.OperationalError:
        pass  # Column already exists

    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO paraphrasing_logs 
            (user_id, username, model_used, complexity_level, original_text, paraphrased_text, similarity_score, original_length, paraphrased_length)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (user_id, username, model_used, complexity_level, original_text, paraphrased_text, similarity_score, original_length, paraphrased_length))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Error logging paraphrasing: {e}")
        return False

def get_recent_activity(user_id: int, limit: int = 5):
    """Get recent user activity from both logs"""
    try:
        db_path = os.path.join(os.path.dirname(__file__), 'data', 'app.db')
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Get recent summarizations
        cursor.execute('''
            SELECT 'summarization' as type, timestamp, model_used, 
                   substr(original_text, 1, 100) || '...' as preview, 
                   rouge1_score, rouge2_score, rougeL_score
            FROM summarization_logs 
            WHERE user_id = ? 
            ORDER BY timestamp DESC 
            LIMIT ?
        ''', (user_id, limit))
        
        summarizations = cursor.fetchall()
        
        # Get recent paraphrases
        cursor.execute('''
            SELECT 'paraphrasing' as type, timestamp, model_used, 
                   substr(original_text, 1, 100) || '...' as preview, 
                   complexity_level, similarity_score
            FROM paraphrasing_logs 
            WHERE user_id = ? 
            ORDER BY timestamp DESC 
            LIMIT ?
        ''', (user_id, limit))
        
        paraphrases = cursor.fetchall()
        
        conn.close()
        
        # Combine and sort by timestamp
        all_activity = summarizations + paraphrases
        all_activity.sort(key=lambda x: x[1], reverse=True)
        
        return all_activity[:limit]
        
    except Exception as e:
        print(f"Error getting recent activity: {e}")
        return []
    
    # Add this endpoint to authentication.py
@app.get("/recent-activity")
def get_recent_activity_endpoint(current_user: UserOut = Depends(get_current_user), 
                               db: sqlite3.Connection = Depends(get_db)):
    """Get recent user activity"""
    try:
        cursor = db.cursor()
        
        # Get recent summarizations
        cursor.execute('''
            SELECT 'summarization' as type, timestamp, model_used, 
                   substr(original_text, 1, 100) || '...' as preview, 
                   rouge1_score, rouge2_score, rougeL_score
            FROM summarization_logs 
            WHERE user_id = ? 
            ORDER BY timestamp DESC 
            LIMIT 5
        ''', (current_user.id,))
        
        summarizations = []
        for row in cursor.fetchall():
            summarizations.append({
                'type': row[0],
                'timestamp': row[1],
                'model_used': row[2],
                'preview': row[3],
                'rouge1_score': row[4],
                'rouge2_score': row[5],
                'rougeL_score': row[6]
            })
        
        # Get recent paraphrases
        cursor.execute('''
            SELECT 'paraphrasing' as type, timestamp, model_used, 
                   substr(original_text, 1, 100) || '...' as preview, 
                   complexity_level, similarity_score, original_length, paraphrased_length
    FROM paraphrasing_logs 
    WHERE user_id = ? 
    ORDER BY timestamp DESC 
    LIMIT 5
''', (current_user.id,))

        paraphrases = []
        for row in cursor.fetchall():
            paraphrases.append({
                'type': row[0],
                'timestamp': row[1],
                'model_used': row[2],
                'preview': row[3],
                'complexity_level': row[4],
                'similarity_score': row[5],
                'original_length': row[6],
                'paraphrased_length': row[7]
            })
        
        # Combine and sort by timestamp
        all_activity = summarizations + paraphrases
        all_activity.sort(key=lambda x: x['timestamp'], reverse=True)
        
        return all_activity[:5]
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching activity: {str(e)}")