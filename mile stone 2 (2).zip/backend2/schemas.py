"""from pydantic import BaseModel, EmailStr
from typing import Optional

class UserCreate(BaseModel):
    username: str
    email: EmailStr
    password: str

    class Config:
        orm_mode = True

class UserLogin(BaseModel):
    username: str
    password: str

    class Config:
        orm_mode = True

class UserOut(BaseModel):
    id: int
    username: str
    email: EmailStr

    class Config:
        orm_mode = True

class UserPreferences(BaseModel):
    language: str = 'en'
    reading_style: str = 'neutral'  # Options: neutral, formal, casual, concise
    content_type: str = 'general'   # Options: general, news, academic, technical

    class Config:
        orm_mode = True

class UserProfile(BaseModel):
    user: UserOut
    preferences: UserPreferences

    class Config:
        orm_mode = True

class UserProfileUpdate(BaseModel):
    email: Optional[EmailStr] = None
    preferences: Optional[UserPreferences] = None

    class Config:
        orm_mode = True"""
#previous code
from pydantic import BaseModel, EmailStr
from typing import Optional


class UserCreate(BaseModel):
    username: str
    email: EmailStr
    password: str

    class Config:
        from_attributes = True  # Updated from orm_mode

class UserLogin(BaseModel):
    username: str
    password: str

    class Config:
        from_attributes = True

class UserOut(BaseModel):
    id: int
    username: str
    email: EmailStr

    class Config:
        from_attributes = True

class UserPreferences(BaseModel):
    language: str = 'en'
    reading_style: str = 'neutral'  
    content_type: str = 'general'   

    class Config:
        from_attributes = True

class SummarizationPreferences(BaseModel):
    summary_length: str = 'medium'    
    focus_area: str = 'key_points'    
    complexity_level: str = 'medium'  

    class Config:
        from_attributes = True

class UserProfile(BaseModel):
    user: UserOut
    preferences: UserPreferences
    summarization_prefs: SummarizationPreferences  

    class Config:
        from_attributes = True


class UserProfileUpdate(BaseModel):
    email: Optional[EmailStr] = None
    preferences: Optional[UserPreferences] = None
    summarization_prefs: Optional[SummarizationPreferences] = None  # NEW FIELD

    class Config:
        from_attributes = True
