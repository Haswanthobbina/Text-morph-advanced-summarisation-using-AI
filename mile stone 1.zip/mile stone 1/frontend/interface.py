import sys
from pathlib import Path
import streamlit as st
import httpx
import tempfile
import os
from PyPDF2 import PdfReader
import docx
import textstat
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.tokenize import sent_tokenize
import numpy as np
import matplotlib.pyplot as plt


current_dir = Path(__file__).parent
project_root = current_dir.parent
sys.path.append(str(project_root))
from backend.schemas import UserCreate, UserLogin

st.set_page_config(
    page_title="TextMorph Advanced",
    page_icon="🔮",
    layout="centered",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
    /* DeepSeek Blue Theme */
    :root {
        --primary: #2563EB;       /* DeepSeek blue */
        --primary-dark: #1D4ED8;  /* Darker blue */
        --background: #0F172A;    /* Dark blue background */
        --secondary-background: #1E293B; /* Card background */
        --text: #F1F5F9;          /* Light text */
        --text-secondary: #94A3B8;/* Secondary text */
        --accent: #3B82F6;        /* Accent blue */
    }
    
    .stApp {
        background: linear-gradient(135deg, var(--background) 0%, #1E40AF 100%);
        color: var(--text);
    }
    
    /* Sidebar */
    .css-1d391kg, .css-1d391kg p, .css-1d391kg label {
        background: var(--secondary-background) !important;
        color: var(--text) !important;
        border-right: 2px solid var(--primary);
    }
    
    /* Headers and text */
    h1, h2, h3, h4, h5, h6 {
        color: var(--text) !important;
        font-weight: 700 !important;
    }
    
    p, label, .stTextInput, .stSelectbox, .stTextArea {
        color: var(--text) !important;
    }
    
    /* Buttons */
    .stButton>button {
        background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%) !important;
        color: white !important;
        border: none;
        border-radius: 12px;
        padding: 0.75rem 1.5rem;
        font-weight: 600;
        transition: all 0.3s ease;
    }
    
    .stButton>button:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(37, 99, 235, 0.3);
    }
    
    /* Form inputs */
    .stTextInput>div>div>input, 
    .stSelectbox>div>div>select,
    .stTextArea>div>div>textarea {
        background: var(--secondary-background) !important;
        color: var(--text) !important;
        border: 2px solid #334155;
        border-radius: 10px;
        padding: 12px;
    }
    
    /* File uploader */
    .stFileUploader>div>div {
        background: var(--secondary-background) !important;
        border: 2px dashed var(--primary) !important;
        border-radius: 15px !important;
    }
    
    /* Cards and containers */
    .stForm {
        background: var(--secondary-background) !important;
        border-radius: 20px !important;
        padding: 2rem !important;
        border: 1px solid #334155;
    }
    
    /* Metrics */
    .stMetric {
        background: linear-gradient(135deg, var(--secondary-background) 0%, #2D3748 100%);
        border-radius: 15px;
        padding: 1rem;
        border: 1px solid #334155;
    }
    
    /* Success and error messages */
    .stSuccess {
        background: linear-gradient(135deg, #065F46 0%, #047857 100%) !important;
        color: white !important;
        border-radius: 15px;
        border: none;
    }
    
    .stError {
        background: linear-gradient(135deg, #7F1D1D 0%, #B91C1C 100%) !important;
        color: white !important;
        border-radius: 15px;
        border: none;
    }
    
    .stInfo {
        background: linear-gradient(135deg, var(--secondary-background) 0%, #2D3748 100%) !important;
        color: var(--text) !important;
        border-radius: 15px;
        border: 1px solid var(--primary);
    }
</style>
""", unsafe_allow_html=True)

BACKEND_URL = "http://127.0.0.1:8000"

# Initialize session state
if 'logged_in' not in st.session_state:
    st.session_state.logged_in = False
if 'token' not in st.session_state:
    st.session_state.token = None
if 'profile_image' not in st.session_state:
    st.session_state.profile_image = None

def extract_text_from_file(uploaded_file):
    """Extract text from uploaded files"""
    try:
        if uploaded_file.type == "application/pdf":
            pdf_reader = PdfReader(uploaded_file)
            text = ""
            for page in pdf_reader.pages:
                text += page.extract_text() + "\n"
            return text
        elif uploaded_file.type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
            doc = docx.Document(uploaded_file)
            return "\n".join([paragraph.text for paragraph in doc.paragraphs])
        elif uploaded_file.type == "text/plain":
            return uploaded_file.getvalue().decode("utf-8")
        else:
            return None
    except Exception as e:
        st.error(f"Error extracting text: {e}")
        return None

def generate_summary(text, num_sentences=3):
    """Simple extractive summarization"""
    try:
        sentences = sent_tokenize(text)
        if len(sentences) <= num_sentences:
            return text
        vectorizer = TfidfVectorizer(stop_words='english')
        tfidf_matrix = vectorizer.fit_transform(sentences)
        sentence_scores = np.array(tfidf_matrix.sum(axis=1)).flatten()
        top_sentence_indices = sentence_scores.argsort()[-num_sentences:][::-1]
        top_sentences = [sentences[i] for i in sorted(top_sentence_indices)]
        return " ".join(top_sentences)
    except Exception as e:
        sentences = text.split('.')
        return '. '.join(sentences[:num_sentences]) + '.'

def calculate_readability_scores(text):
    """Calculate readability scores"""
    if not text.strip():
        return None
    try:
        return {
            'flesch_score': textstat.flesch_reading_ease(text),
            'smog_index': textstat.smog_index(text),
            'word_count': len(text.split()),
            'sentence_count': textstat.sentence_count(text),
            'text_complexity': get_complexity_level(textstat.flesch_reading_ease(text))
        }
    except Exception as e:
        st.error(f"Error calculating scores: {e}")
        return None

def get_complexity_level(flesch_score):
    """Convert Flesch score to complexity level"""
    if flesch_score >= 90: return "Very Easy"
    elif flesch_score >= 80: return "Easy"
    elif flesch_score >= 70: return "Fairly Easy"
    elif flesch_score >= 60: return "Standard"
    elif flesch_score >= 50: return "Fairly Difficult"
    elif flesch_score >= 30: return "Difficult"
    else: return "Very Difficult"

def create_visualization(scores, summary_words):
    """Create readability visualization"""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
    
    # Pie chart for complexity
    complexity_levels = ['Very Easy', 'Easy', 'Fairly Easy', 'Standard', 'Fairly Difficult', 'Difficult', 'Very Difficult']
    complexity_values = [0] * 7
    complexity_index = complexity_levels.index(scores['text_complexity'])
    complexity_values[complexity_index] = 1
    
    colors = ['#22C55E', '#4ADE80', '#86EFAC', '#F59E0B', '#F97316', '#EF4444', '#DC2626']
    ax1.pie(complexity_values, labels=complexity_levels, colors=colors, autopct='%1.0f%%')
    ax1.set_title('Text Complexity Level', fontweight='bold', fontsize=14)
    
    # Bar chart for scores
    metrics = ['Flesch Score', 'SMOG Index']
    values = [scores['flesch_score'], scores['smog_index']]
    colors = ['#2563EB', '#8B5CF6']
    bars = ax2.bar(metrics, values, color=colors, alpha=0.8)
    ax2.set_ylabel('Score', fontweight='bold')
    ax2.set_title('Readability Metrics', fontweight='bold', fontsize=14)
    ax2.set_ylim(0, 100)
    
    for bar, value in zip(bars, values):
        ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 2,
                f'{value:.1f}', ha='center', va='bottom', fontweight='bold')
    
    plt.tight_layout()
    return fig

# ========== MAIN INTERFACE ==========
st.title("TextMorph Advanced Summarization 🔮")
st.markdown("---")

# Sidebar navigation
st.sidebar.title("🧭 Navigation")
menu = st.sidebar.selectbox("Menu", ["Login", "Register", "Profile", "Text Analysis"])

if menu == "Register":
    st.header("Create a New Account")
    with st.form("register_form"):
        username = st.text_input("Username")
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("Create Account")
        if submitted:
            try:
                new_user = UserCreate(username=username, email=email, password=password)
                response = httpx.post(f"{BACKEND_URL}/register", json=new_user.dict())
                if response.status_code == 200:
                    st.success("Registration successful! Please log in.")
                else:
                    st.error(response.json().get('detail', 'Registration failed'))
            except Exception as e:
                st.error(f"An error occurred: {e}")

elif menu == "Login":
    st.header("Login to Your Account")
    with st.form("login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("Login")
        if submitted:
            try:
                form_data = {'username': username, 'password': password}
                response = httpx.post(f"{BACKEND_URL}/token", data=form_data)
                if response.status_code == 200:
                    token_data = response.json()
                    st.session_state.logged_in = True
                    st.session_state.token = token_data['access_token']
                    st.success("Login successful!")
                    st.rerun()
                else:
                    st.error("Invalid username or password")
            except Exception as e:
                st.error(f"Login failed: {e}")

elif menu == "Profile":
    if not st.session_state.logged_in:
        st.warning("Please log in to view your profile.")
    else:
        st.header("Your Profile")
        
        # Profile picture upload
        st.subheader("🖼️ Profile Picture")
        uploaded_image = st.file_uploader("Upload profile image", type=['png', 'jpg', 'jpeg'])
        if uploaded_image:
            st.session_state.profile_image = uploaded_image
            st.image(uploaded_image, width=150)
        
        try:
            headers = {"Authorization": f"Bearer {st.session_state.token}"}
            response = httpx.get(f"{BACKEND_URL}/profile", headers=headers)
            
            if response.status_code == 200:
                profile_data = response.json()
                user = profile_data['user']
                prefs = profile_data['preferences']

                with st.form("profile_form"):
                    st.subheader("Account Information")
                    st.text_input("Username", value=user['username'], disabled=True)
                    new_email = st.text_input("Email", value=user['email'])

                    st.subheader("Reading Preferences")
                    language = st.selectbox("Preferred Language", options=['en', 'es', 'fr', 'de'])
                    reading_style = st.selectbox("Reading Style", options=['neutral', 'formal', 'casual', 'concise'])
                    content_type = st.selectbox("Content Type", options=['general', 'news', 'academic', 'technical'])

                    submitted = st.form_submit_button("Update Profile")
                    if submitted:
                        update_data = {
                            "email": new_email,
                            "preferences": {"language": language, "reading_style": reading_style, "content_type": content_type}
                        }
                        update_response = httpx.put(f"{BACKEND_URL}/profile", json=update_data, headers=headers)
                        if update_response.status_code == 200:
                            st.success("Profile updated successfully!")
                        else:
                            st.error("Failed to update profile.")
            else:
                st.error("Could not fetch your profile.")
        except Exception as e:
            st.error(f"An error occurred: {e}")

elif menu == "Text Analysis":
    if not st.session_state.logged_in:
        st.warning("Please log in to analyze text.")
    else:
        st.header("📊 Text Analysis & Summarization")
        
        # File upload section
        st.subheader("📁 Upload File")
        uploaded_file = st.file_uploader("Choose a file", type=['txt', 'pdf', 'docx'])
        
        extracted_text = ""
        if uploaded_file is not None:
            extracted_text = extract_text_from_file(uploaded_file)
            if extracted_text:
                st.success("✅ File uploaded successfully!")
                with st.expander("View Extracted Text"):
                    st.text_area("Text", extracted_text, height=150, disabled=True)
        
        # Direct text input
        st.subheader("📝 Or Enter Text Directly")
        direct_text = st.text_area("Paste your text here:", height=100)
        
        final_text = extracted_text if extracted_text else direct_text
        
        if st.button("Analyze & Summarize", type="primary") and final_text.strip():
            with st.spinner("Analyzing text..."):
                scores = calculate_readability_scores(final_text)
                
                if scores:
                    summary = generate_summary(final_text)
                    
                    # Display scores
                    st.subheader("📈 Readability Analysis")
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Flesch Score", f"{scores['flesch_score']:.1f}", scores['text_complexity'])
                    with col2:
                        st.metric("SMOG Index", f"{scores['smog_index']:.1f}")
                    with col3:
                        st.metric("Word Count", scores['word_count'])
                    
                    # Display summary
                    st.subheader("📝 Generated Summary")
                    st.info(summary)
                    
                    # Show statistics
                    summary_words = len(summary.split())
                    reduction = ((scores['word_count'] - summary_words) / scores['word_count']) * 100
                    st.write(f"**Summary Statistics:** {summary_words} words ({reduction:.1f}% reduction)")
                    
                    # Visualization
                    st.subheader("📊 Visualization")
                    fig = create_visualization(scores, summary_words)
                    st.pyplot(fig)

# Logout and status
if st.session_state.logged_in:
    st.sidebar.success("✅ Logged In")
    if st.sidebar.button("🚪 Logout"):
        st.session_state.logged_in = False
        st.session_state.token = None
        st.session_state.profile_image = None
        st.rerun()
    
    st.sidebar.header("Quick Access")
    if st.sidebar.button("📊 Analyze Text"):
        st.session_state.menu = "Text Analysis"
        st.rerun()
else:
    st.info("👈 Please register or login from the sidebar to get started.")

    
    
    
    
    
    
    
  #  '''***How to Customize the Colors:
#The colors are controlled by CSS variables at the top of the custom CSS. To change the theme, edit these values:

#css
#:root 
#{
 #      --primary: #6366F1;       /* Change this for main buttons and accents */
  #  --background: #0E1117;    /* Main background color */
   # --secondary-background: #262730;  /* Sidebar and form backgrounds */
    #--text: #FAFAFA;          /* Text color */
#}popular Color Schemes You Can Try:
#Purple Theme: --primary: #8B5CF6; --background: #1F2937;

#Blue Theme: --primary: #3B82F6; --background: #0F172A;

#Emerald Theme: --primary: #10B981; --background: #064E3B; --text: #ECFDF5;

#Light Theme: Remove the custom CSS and use: st.set_page_config(theme="light")

#To See the Theme:
#save the updated interface.py file

#Make sure your backend is running: uvicorn backend.authentication:app --reload

#Run your frontend: streamlit run frontend/interface.py***'''