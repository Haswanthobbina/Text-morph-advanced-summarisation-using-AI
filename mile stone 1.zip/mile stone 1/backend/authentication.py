"""import os
import sqlite3
from datetime import datetime, timedelta
from typing import Optional

from fastapi import FastAPI, Depends, HTTPException, status, Body
from transformers import pipeline
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import JWTError, jwt
from passlib.context import CryptContext

from backend.schemas import UserCreate, UserLogin, UserOut, UserProfile, UserProfileUpdate, UserPreferences

app = FastAPI()

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

SECRET_KEY = os.getenv("SECRET_KEY", "your-secret-key-here-change-in-production")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30


def get_db():
    conn = sqlite3.connect('data/app.db')
    try:
        yield conn
    finally:
        conn.close()


def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def get_current_user(token: str = Depends(oauth2_scheme), db: sqlite3.Connection = Depends(get_db)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authentication credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    cursor = db.cursor()
    cursor.execute("SELECT id, username, email FROM users WHERE username = ?", (username,))
    user_data = cursor.fetchone()
    if not user_data:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    return UserOut(id=user_data[0], username=user_data[1], email=user_data[2])

# Authentication endpoints
@app.post("/register")
def register(user: UserCreate, db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    
    # Check if user already exists
    cursor.execute("SELECT id FROM users WHERE username = ? OR email = ?", (user.username, user.email))
    existing_user = cursor.fetchone()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username or email already registered"
        )
    
    # Hash password and create user
    hashed_password = get_password_hash(user.password)
    cursor.execute(
        "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)",
        (user.username, user.email, hashed_password)
    )
    db.commit()
    
    return {"message": "User created successfully"}

# FIXED LOGIN ENDPOINT - Using OAuth2PasswordRequestForm
@app.post("/token")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    
    print(f"🔐 LOGIN ATTEMPT - Username: {form_data.username}, Password: {form_data.password}")
    
    cursor.execute("SELECT id, username, email, password_hash FROM users WHERE username = ?", (form_data.username,))
    user_data = cursor.fetchone()
    
    if not user_data:
        print("❌ USER NOT FOUND")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    print(f"✅ USER FOUND: {user_data[1]}")
    print(f"🔑 Verifying password...")
    
    if not verify_password(form_data.password, user_data[3]):
        print("❌ PASSWORD VERIFICATION FAILED")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    print("✅ LOGIN SUCCESSFUL!")
    
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user_data[1]}, expires_delta=access_token_expires
    )
    
    return {"access_token": access_token, "token_type": "bearer"}

# Profile endpoints
@app.get("/profile", response_model=UserProfile)
def get_profile(current_user: UserOut = Depends(get_current_user), db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    
    # Get user preferences
    cursor.execute("SELECT language, reading_style, content_type FROM user_preferences WHERE user_id = ?", (current_user.id,))
    prefs_data = cursor.fetchone()
    
    if prefs_data:
        preferences = UserPreferences(language=prefs_data[0], reading_style=prefs_data[1], content_type=prefs_data[2])
    else:
        # If no preferences exist, create default ones
        preferences = UserPreferences()
        cursor.execute(
            "INSERT INTO user_preferences (user_id, language, reading_style, content_type) VALUES (?, ?, ?, ?)",
            (current_user.id, preferences.language, preferences.reading_style, preferences.content_type)
        )
        db.commit()

    return UserProfile(user=current_user, preferences=preferences)

@app.put("/profile", response_model=UserProfile)
def update_profile(profile_update: UserProfileUpdate, current_user: UserOut = Depends(get_current_user), db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    
    # Update email if provided
    if profile_update.email is not None:
        cursor.execute("UPDATE users SET email = ? WHERE id = ?", (profile_update.email, current_user.id))
        db.commit()
    
    # Update preferences if provided
    if profile_update.preferences is not None:
        prefs = profile_update.preferences
        cursor.execute('''
            INSERT INTO user_preferences (user_id, language, reading_style, content_type)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
            language=excluded.language,
            reading_style=excluded.reading_style,
            content_type=excluded.content_type
        ''', (current_user.id, prefs.language, prefs.reading_style, prefs.content_type))
        db.commit()
    
    # Return the updated profile by fetching it again
    cursor.execute("SELECT language, reading_style, content_type FROM user_preferences WHERE user_id = ?", (current_user.id,))
    prefs_data = cursor.fetchone()
    
    if prefs_data:
        preferences = UserPreferences(language=prefs_data[0], reading_style=prefs_data[1], content_type=prefs_data[2])
    else:
        preferences = UserPreferences()
    
    return UserProfile(user=current_user, preferences=preferences)"""

    #uvicorn backend.authentication:app --reload  
    #To run the server, use the command above in your terminal

import os
import sqlite3
from datetime import datetime, timedelta
from typing import Optional

from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import JWTError, jwt
from passlib.context import CryptContext

from backend.schemas import UserCreate, UserLogin, UserOut, UserProfile, UserProfileUpdate, UserPreferences, SummarizationPreferences

app = FastAPI()

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

SECRET_KEY = os.getenv("SECRET_KEY", "your-secret-key-here-change-in-production")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

def get_db():
    conn = sqlite3.connect('data/app.db')
    try:
        yield conn
    finally:
        conn.close()

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def get_current_user(token: str = Depends(oauth2_scheme), db: sqlite3.Connection = Depends(get_db)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authentication credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    cursor = db.cursor()
    cursor.execute("SELECT id, username, email FROM users WHERE username = ?", (username,))
    user_data = cursor.fetchone()
    if not user_data:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    return UserOut(id=user_data[0], username=user_data[1], email=user_data[2])

@app.post("/register")
def register(user: UserCreate, db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    
    cursor.execute("SELECT id FROM users WHERE username = ? OR email = ?", (user.username, user.email))
    existing_user = cursor.fetchone()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username or email already registered"
        )
    
    hashed_password = get_password_hash(user.password)
    cursor.execute(
        "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)",
        (user.username, user.email, hashed_password)
    )
    db.commit()
    
    return {"message": "User created successfully"}

@app.post("/token")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    
    print(f"🔐 LOGIN ATTEMPT - Username: {form_data.username}, Password: {form_data.password}")
    
    cursor.execute("SELECT id, username, email, password_hash FROM users WHERE username = ?", (form_data.username,))
    user_data = cursor.fetchone()
    
    if not user_data:
        print("❌ USER NOT FOUND")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    print(f"✅ USER FOUND: {user_data[1]}")
    print(f"🔑 Verifying password...")
    
    if not verify_password(form_data.password, user_data[3]):
        print("❌ PASSWORD VERIFICATION FAILED")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    print("✅ LOGIN SUCCESSFUL!")
    
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user_data[1]}, expires_delta=access_token_expires
    )
    
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/profile", response_model=UserProfile)
def get_profile(current_user: UserOut = Depends(get_current_user), db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    
    cursor.execute("SELECT language, reading_style, content_type FROM user_preferences WHERE user_id = ?", (current_user.id,))
    prefs_data = cursor.fetchone()
    
    cursor.execute("SELECT summary_length, focus_area, complexity_level FROM user_summarization_prefs WHERE user_id = ?", (current_user.id,))
    summarization_prefs_data = cursor.fetchone()
    
    if prefs_data:
        preferences = UserPreferences(language=prefs_data[0], reading_style=prefs_data[1], content_type=prefs_data[2])
    else:
        preferences = UserPreferences()
        cursor.execute(
            "INSERT INTO user_preferences (user_id, language, reading_style, content_type) VALUES (?, ?, ?, ?)",
            (current_user.id, preferences.language, preferences.reading_style, preferences.content_type)
        )
    
    if summarization_prefs_data:
        summarization_prefs = SummarizationPreferences(
            summary_length=summarization_prefs_data[0],
            focus_area=summarization_prefs_data[1],
            complexity_level=summarization_prefs_data[2]
        )
    else:
        summarization_prefs = SummarizationPreferences()
        cursor.execute(
            "INSERT INTO user_summarization_prefs (user_id, summary_length, focus_area, complexity_level) VALUES (?, ?, ?, ?)",
            (current_user.id, summarization_prefs.summary_length, summarization_prefs.focus_area, summarization_prefs.complexity_level)
        )
    
    db.commit()
    return UserProfile(user=current_user, preferences=preferences, summarization_prefs=summarization_prefs)

@app.put("/profile", response_model=UserProfile)
def update_profile(profile_update: UserProfileUpdate, current_user: UserOut = Depends(get_current_user), db: sqlite3.Connection = Depends(get_db)):
    cursor = db.cursor()
    
    if profile_update.email is not None:
        cursor.execute("UPDATE users SET email = ? WHERE id = ?", (profile_update.email, current_user.id))
    
    if profile_update.preferences is not None:
        prefs = profile_update.preferences
        cursor.execute('''
            INSERT INTO user_preferences (user_id, language, reading_style, content_type)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
            language=excluded.language,
            reading_style=excluded.reading_style,
            content_type=excluded.content_type
        ''', (current_user.id, prefs.language, prefs.reading_style, prefs.content_type))
    
    if profile_update.summarization_prefs is not None:
        summarization_prefs = profile_update.summarization_prefs
        cursor.execute('''
            INSERT INTO user_summarization_prefs (user_id, summary_length, focus_area, complexity_level)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
            summary_length=excluded.summary_length,
            focus_area=excluded.focus_area,
            complexity_level=excluded.complexity_level
        ''', (current_user.id, summarization_prefs.summary_length, summarization_prefs.focus_area, summarization_prefs.complexity_level))
    
    db.commit()
    return get_profile(current_user, db)