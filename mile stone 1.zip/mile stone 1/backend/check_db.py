import sqlite3
from passlib.context import CryptContext

def show_database():
    pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
    
    conn = sqlite3.connect('data/app.db')
    cursor = conn.cursor()
    
    print("=" * 60)
    print("DATABASE DEMONSTRATION")
    print("=" * 60)
    
    # Show all users
    print("\n USERS TABLE:")
    cursor.execute("SELECT id, username, email, password_hash FROM users")
    users = cursor.fetchall()
    for user in users:
        print(f"ID: {user[0]}, Username: {user[1]}, Email: {user[2]}")
        print(f"Password Hash: {user[3][:30]}... (securely hashed with bcrypt)")
        print("-" * 40)
    
    print("\n USER PREFERENCES TABLE IN PROFILE SECTION:")
    cursor.execute("SELECT user_id, language, reading_style, content_type FROM user_preferences")
    prefs = cursor.fetchall()
    for pref in prefs:
        print(f"User ID: {pref[0]}, Language: {pref[1]}, Style: {pref[2]}, Content Type: {pref[3]}")
    
    print("\n SUMMARIZATION PREFERENCES TABLE:")
    cursor.execute("SELECT user_id, summary_length, focus_area, complexity_level FROM user_summarization_prefs")
    summarization_prefs = cursor.fetchall()
    for pref in summarization_prefs:
        print(f"User ID: {pref[0]}, Length: {pref[1]}, Focus: {pref[2]}, Complexity: {pref[3]}")
    
    conn.close()
    print("\nDatabase demonstration completed.")

if __name__ == "__main__":
    show_database()