# backend/test_login.py
import sqlite3
from passlib.context import CryptContext

def test_login():
    # Setup
    pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
    conn = sqlite3.connect('data/app.db')
    cursor = conn.cursor()
    
    # Get all users from database
    cursor.execute("SELECT username, password_hash FROM users")
    users = cursor.fetchall()
    
    print("🧪 TESTING LOGIN SYSTEM")
    print("=" * 50)
    
    for username, password_hash in users:
        print(f"\nTesting user: {username}")
        print(f"Stored hash: {password_hash}")
        
        # Test with correct password (you need to know what you used)
        test_password = input(f"Enter the password you used for '{username}': ")
        
        # Test verification
        is_valid = pwd_context.verify(test_password, password_hash)
        print(f"Password verification: {is_valid}")
        
        if not is_valid:
            print("❌ VERIFICATION FAILED")
            # Let's see what a new hash of the same password looks like
            new_hash = pwd_context.hash(test_password)
            print(f"New hash of same password: {new_hash}")
            print(f"Hashes match: {new_hash == password_hash}")
        else:
            print("✅ VERIFICATION SUCCESS!")
    
    conn.close()

if __name__ == "__main__":
    test_login()

    # backend/test_register.py
import sqlite3
from passlib.context import CryptContext

def test_register():
    pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
    conn = sqlite3.connect('data/app.db')
    cursor = conn.cursor()
    
    username = "testuser"
    email = "test@test.com"
    password = "test123"
    
    # Hash password
    hashed_password = pwd_context.hash(password)
    
    # Insert user
    cursor.execute(
        "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)",
        (username, email, hashed_password)
    )
    conn.commit()
    
    print(f"✅ Created test user:")
    print(f"Username: {username}")
    print(f"Password: {password}") 
    print(f"Hashed: {hashed_password}")
    
    # Test verification immediately
    is_valid = pwd_context.verify(password, hashed_password)
    print(f"Immediate verification test: {is_valid}")
    
    conn.close()

if __name__ == "__main__":
    test_register()