"""
import sqlite3

def init_db():
    conn = sqlite3.connect('data/app.db')
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_preferences (
            user_id INTEGER PRIMARY KEY,
            language TEXT DEFAULT 'en',
            reading_style TEXT DEFAULT 'neutral', -- e.g., 'formal', 'casual', 'concise'
            content_type TEXT DEFAULT 'general', -- e.g., 'news', 'academic', 'technical'
            FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
        )
    ''')
    conn.commit()
    conn.close()

if __name__ == "__main__":
    init_db()
    print("Database initialized successfully.") 
    """
#previous code 

import sqlite3

def init_db():
    conn = sqlite3.connect('data/app.db')
    cursor = conn.cursor()

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_preferences (
            user_id INTEGER PRIMARY KEY,
            language TEXT DEFAULT 'en',
            reading_style TEXT DEFAULT 'neutral',
            content_type TEXT DEFAULT 'general',
            FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
        )
    ''')

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_summarization_prefs (
            user_id INTEGER PRIMARY KEY,
            summary_length TEXT DEFAULT 'medium',
            focus_area TEXT DEFAULT 'key_points',
            complexity_level TEXT DEFAULT 'medium',
            FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
        )
    ''')

    conn.commit()
    conn.close()

if __name__ == "__main__":
    init_db()
    print("Database initialized successfully with summarization preferences table.")